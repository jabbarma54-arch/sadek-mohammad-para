import React, { useState } from 'react';
import { Image as ImageIcon, Video, Filter, Eye, X } from 'lucide-react';
import { GalleryItem } from '../types';

interface GallerySectionProps {
  gallery: GalleryItem[];
}

export const GallerySection: React.FC<GallerySectionProps> = ({ gallery }) => {
  const [selectedCategory, setSelectedCategory] = useState('সবগুলো');
  const [activeItem, setActiveItem] = useState<GalleryItem | null>(null);

  const categories = ['সবগুলো', 'মানবতা', 'ইভেন্ট', 'স্বাস্থ্য', 'উদ্বোধন'];

  const filteredGallery = gallery.filter(item => selectedCategory === 'সবগুলো' || item.category === selectedCategory);

  return (
    <div className="space-y-6 pb-12">
      {/* Title */}
      <div className="text-center space-y-2 max-w-xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-100 dark:bg-indigo-950 text-indigo-800 dark:text-indigo-300 text-xs font-bold">
          <ImageIcon className="w-4 h-4" />
          <span>ছবি ও ভিডিও অ্যালবাম</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white font-['Noto_Serif_Bengali']">
          কার্যক্রমের ফটো গ্যালারি
        </h2>
        <p className="text-slate-600 dark:text-slate-300 text-sm">
          ছাদেক মোহাম্মদ পাড়া ঐক্য পরিষদের ঐতিহাসিক মুহূর্ত ও সমাজসেবামূলক কাজের ছবি সংগ্রহ
        </p>
      </div>

      {/* Category Filters */}
      <div className="flex flex-wrap items-center justify-center gap-2">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-4 py-1.5 rounded-xl text-xs font-bold transition ${
              selectedCategory === cat
                ? 'bg-emerald-600 text-white shadow'
                : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Gallery Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-5">
        {filteredGallery.map((item) => (
          <div
            key={item.id}
            onClick={() => setActiveItem(item)}
            className="group relative bg-white dark:bg-slate-900 rounded-3xl overflow-hidden border border-slate-200/80 dark:border-slate-800 shadow-sm cursor-pointer hover:shadow-lg transition"
          >
            <div className="relative h-56 overflow-hidden">
              <img
                src={item.imageUrl}
                alt={item.title}
                className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent opacity-80 group-hover:opacity-90 transition"></div>

              <span className="absolute top-3 left-3 bg-white/20 backdrop-blur-md text-white font-bold text-[10px] px-2.5 py-1 rounded-lg border border-white/20">
                {item.category}
              </span>

              <div className="absolute bottom-3 left-3 right-3 text-white space-y-1">
                <h4 className="text-sm font-bold font-['Noto_Serif_Bengali'] line-clamp-1">{item.title}</h4>
                <p className="text-[10px] text-slate-300">📅 {item.date}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Lightbox Preview Modal */}
      {activeItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="relative max-w-2xl w-full bg-white dark:bg-slate-900 rounded-3xl overflow-hidden shadow-2xl border border-slate-800 space-y-4">
            <button
              onClick={() => setActiveItem(null)}
              className="absolute top-4 right-4 z-10 p-2 rounded-full bg-slate-900/80 text-white hover:bg-slate-800 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <img
              src={activeItem.imageUrl}
              alt={activeItem.title}
              className="w-full h-80 object-cover"
            />

            <div className="p-6 space-y-2">
              <div className="flex items-center gap-2">
                <span className="px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 font-bold text-xs">
                  {activeItem.category}
                </span>
                <span className="text-xs text-slate-400">তারিখ: {activeItem.date}</span>
              </div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white font-['Noto_Serif_Bengali']">
                {activeItem.title}
              </h3>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
