import React, { useState } from 'react';
import { ShieldAlert, PlusCircle, UserCheck, Bell, CreditCard, Calendar, CheckCircle2, Trash2 } from 'lucide-react';
import { Member, Notice, EventItem, Donation } from '../types';

interface AdminPanelProps {
  members: Member[];
  onApproveMember: (id: string) => void;
  notices: Notice[];
  onAddNotice: (newNotice: Notice) => void;
  events: EventItem[];
  onAddEvent: (newEvent: EventItem) => void;
  donations: Donation[];
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  members,
  onApproveMember,
  notices,
  onAddNotice,
  events,
  onAddEvent,
  donations
}) => {
  const [activeTab, setActiveTab] = useState<'members' | 'notices' | 'events' | 'ledger'>('notices');

  // New Notice form state
  const [noticeTitle, setNoticeTitle] = useState('');
  const [noticeCategory, setNoticeCategory] = useState<'জরুরি' | 'সভা' | 'ইভেন্ট' | 'সাধারণ'>('জরুরি');
  const [noticeContent, setNoticeContent] = useState('');
  const [noticeIsUrgent, setNoticeIsUrgent] = useState(true);
  const [noticeSuccess, setNoticeSuccess] = useState(false);

  // New Event form state
  const [eventTitle, setEventTitle] = useState('');
  const [eventDate, setEventDate] = useState('');
  const [eventTime, setEventTime] = useState('বিকাল ০৪:০০');
  const [eventLocation, setEventLocation] = useState('ছাদেক মোহাম্মদ পাড়া মাঠ');
  const [eventDesc, setEventDesc] = useState('');

  const handleCreateNotice = (e: React.FormEvent) => {
    e.preventDefault();
    if (!noticeTitle || !noticeContent) return;

    const newN: Notice = {
      id: `n${Date.now()}`,
      title: noticeTitle,
      date: new Date().toISOString().split('T')[0],
      category: noticeCategory,
      content: noticeContent,
      isUrgent: noticeIsUrgent,
      publishedBy: 'অফিসিয়াল এডমিন'
    };

    onAddNotice(newN);
    setNoticeSuccess(true);
    setNoticeTitle('');
    setNoticeContent('');
    setTimeout(() => setNoticeSuccess(false), 3000);
  };

  const handleCreateEvent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!eventTitle || !eventDate) return;

    const newE: EventItem = {
      id: `e${Date.now()}`,
      title: eventTitle,
      date: eventDate,
      time: eventTime,
      location: eventLocation,
      description: eventDesc,
      category: 'ইভেন্ট',
      status: 'upcoming'
    };

    onAddEvent(newE);
    setEventTitle('');
    setEventDesc('');
    alert('ইভেন্ট সফলভাবে যোগ করা হয়েছে!');
  };

  const totalDonationsAmount = donations.reduce((sum, d) => sum + d.amount, 0);

  return (
    <div className="space-y-6 pb-12">
      {/* Title */}
      <div className="text-center space-y-2 max-w-xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 text-xs font-bold">
          <ShieldAlert className="w-4 h-4" />
          <span>এডমিন প্যানেল কন্ট্রোল রুম</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white font-['Noto_Serif_Bengali']">
          পরিচালনা পর্ষদ কন্ট্রোল সেন্টার
        </h2>
        <p className="text-slate-600 dark:text-slate-300 text-sm">
          সদস্য অনুমোদন, নতুন নোটিশ প্রকাশ, ইভেন্ট ঘোষণা ও অনুদানের হিসাব সংরক্ষণ
        </p>
      </div>

      {/* Admin Tab Switcher */}
      <div className="max-w-2xl mx-auto bg-slate-200 dark:bg-slate-800 p-1.5 rounded-2xl flex items-center gap-1">
        <button
          onClick={() => setActiveTab('notices')}
          className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1 ${
            activeTab === 'notices' ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow' : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          <Bell className="w-3.5 h-3.5 text-amber-500" />
          <span>নোটিশ প্রকাশ</span>
        </button>

        <button
          onClick={() => setActiveTab('members')}
          className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1 ${
            activeTab === 'members' ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow' : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          <UserCheck className="w-3.5 h-3.5 text-emerald-500" />
          <span>সদস্য অনুমোদন ({members.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('events')}
          className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1 ${
            activeTab === 'events' ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow' : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          <Calendar className="w-3.5 h-3.5 text-sky-500" />
          <span>নতুন ইভেন্ট</span>
        </button>

        <button
          onClick={() => setActiveTab('ledger')}
          className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1 ${
            activeTab === 'ledger' ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow' : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          <CreditCard className="w-3.5 h-3.5 text-teal-500" />
          <span>অনুদানের হিসাব</span>
        </button>
      </div>

      {/* Tab 1: Publish Notice */}
      {activeTab === 'notices' && (
        <form onSubmit={handleCreateNotice} className="max-w-xl mx-auto bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
          <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2 font-['Noto_Serif_Bengali']">
            <PlusCircle className="w-4 h-4 text-emerald-600" />
            <span>নতুন নোটিশ বা জরুরি ঘোষণা প্রকাশ করুন</span>
          </h3>

          {noticeSuccess && (
            <div className="p-3 bg-emerald-100 text-emerald-800 rounded-xl text-xs font-bold flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>নোটিশ সফলভাবে প্রকাশিত হয়েছে!</span>
            </div>
          )}

          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
              নোটিশের শিরোনাম *
            </label>
            <input
              type="text"
              required
              value={noticeTitle}
              onChange={(e) => setNoticeTitle(e.target.value)}
              placeholder="শিরোনাম লিখুন"
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 text-sm text-slate-900 dark:text-white outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                ক্যাটাগরি
              </label>
              <select
                value={noticeCategory}
                onChange={(e) => setNoticeCategory(e.target.value as any)}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 text-xs text-slate-900 dark:text-white outline-none"
              >
                <option value="জরুরি">জরুরি</option>
                <option value="সভা">সভা</option>
                <option value="ইভেন্ট">ইভেন্ট</option>
                <option value="সাধারণ">সাধারণ</option>
              </select>
            </div>

            <div className="space-y-1 flex items-end">
              <label className="flex items-center gap-2 p-3 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 cursor-pointer w-full text-xs font-bold">
                <input
                  type="checkbox"
                  checked={noticeIsUrgent}
                  onChange={(e) => setNoticeIsUrgent(e.target.checked)}
                  className="rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4"
                />
                <span>জরুরি নোটিশ ব্যানার</span>
              </label>
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
              বিস্তারিত বিবরণ *
            </label>
            <textarea
              required
              rows={4}
              value={noticeContent}
              onChange={(e) => setNoticeContent(e.target.value)}
              placeholder="নোটিশের বিস্তারিত বার্তা লিখুন..."
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 text-sm text-slate-900 dark:text-white outline-none resize-none"
            ></textarea>
          </div>

          <button
            type="submit"
            className="w-full py-3.5 rounded-2xl bg-amber-500 text-slate-950 font-extrabold text-sm shadow hover:bg-amber-400 transition"
          >
            নোটিশ প্রকাশ করুন
          </button>
        </form>
      )}

      {/* Tab 2: Approve Members */}
      {activeTab === 'members' && (
        <div className="max-w-2xl mx-auto bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
          <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center justify-between">
            <span>অনুমোদিত সদস্য তালিকা ({members.length})</span>
            <span className="text-xs text-emerald-600 font-bold">সকলের তথ্য সংরক্ষিত</span>
          </h3>

          <div className="space-y-3">
            {members.map((m) => (
              <div
                key={m.id}
                className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-between gap-3 text-xs"
              >
                <div className="flex items-center gap-3">
                  <img src={m.photoUrl} alt={m.nameBn} className="w-10 h-10 rounded-xl object-cover" />
                  <div>
                    <h4 className="font-bold text-slate-900 dark:text-white text-sm">{m.nameBn}</h4>
                    <p className="text-slate-500">{m.memberNo} • {m.phone}</p>
                  </div>
                </div>

                <span className="px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 font-extrabold text-[10px]">
                  ✓ অনুমোদিত
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 3: Create Event */}
      {activeTab === 'events' && (
        <form onSubmit={handleCreateEvent} className="max-w-xl mx-auto bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
          <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2 font-['Noto_Serif_Bengali']">
            <Calendar className="w-4 h-4 text-sky-600" />
            <span>নতুন ইভেন্ট বা কর্মসূচি সূচি যোগ করুন</span>
          </h3>

          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
              ইভেন্টের নাম *
            </label>
            <input
              type="text"
              required
              value={eventTitle}
              onChange={(e) => setEventTitle(e.target.value)}
              placeholder="যেমন: বার্ষিক ক্রীড়া প্রতিযোগিতা"
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 text-sm text-slate-900 dark:text-white outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                তারিখ (YYYY-MM-DD) *
              </label>
              <input
                type="date"
                required
                value={eventDate}
                onChange={(e) => setEventDate(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 text-xs text-slate-900 dark:text-white outline-none"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                সময়
              </label>
              <input
                type="text"
                value={eventTime}
                onChange={(e) => setEventTime(e.target.value)}
                placeholder="বিকাল ০৪:০০"
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 text-xs text-slate-900 dark:text-white outline-none"
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
              স্থান
            </label>
            <input
              type="text"
              value={eventLocation}
              onChange={(e) => setEventLocation(e.target.value)}
              placeholder="স্থান লিখুন"
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 text-sm text-slate-900 dark:text-white outline-none"
            />
          </div>

          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
              বিবরণ
            </label>
            <textarea
              rows={3}
              value={eventDesc}
              onChange={(e) => setEventDesc(e.target.value)}
              placeholder="ইভেন্টের বিস্তারিত তথ্য..."
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 text-sm text-slate-900 dark:text-white outline-none resize-none"
            ></textarea>
          </div>

          <button
            type="submit"
            className="w-full py-3.5 rounded-2xl bg-sky-600 hover:bg-sky-500 text-white font-extrabold text-sm shadow transition"
          >
            ইভেন্ট সেভ করুন
          </button>
        </form>
      )}

      {/* Tab 4: Ledger Overview */}
      {activeTab === 'ledger' && (
        <div className="max-w-2xl mx-auto bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
          <div className="bg-emerald-900 text-white p-4 rounded-2xl flex items-center justify-between">
            <div>
              <span className="text-xs text-emerald-300 block font-medium">মোট সংগৃহীত অনুদান তহবিল</span>
              <span className="text-2xl font-black text-amber-300">৳{totalDonationsAmount.toLocaleString('bn-BD')}</span>
            </div>
            <span className="px-3 py-1 rounded-full bg-emerald-800 text-emerald-200 text-xs font-bold">
              স্বচ্ছ লেজার
            </span>
          </div>

          <div className="space-y-2">
            <h4 className="text-xs font-bold text-slate-500 uppercase">সর্বশেষ অনুদানের হিসাবসমূহ:</h4>
            {donations.map((d) => (
              <div key={d.id} className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl flex justify-between text-xs">
                <div>
                  <p className="font-bold text-slate-900 dark:text-white">{d.donorName} ({d.method})</p>
                  <p className="text-[11px] text-slate-500">Txn: {d.transactionId} • {d.cause}</p>
                </div>
                <span className="font-black text-emerald-600 text-sm">৳{d.amount.toLocaleString('bn-BD')}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
