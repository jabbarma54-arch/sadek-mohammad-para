import React, { useState } from 'react';
import { CreditCard, QrCode, Copy, CheckCircle2, Download, Printer, ShieldCheck, Heart } from 'lucide-react';
import { Donation } from '../types';

interface DonationSectionProps {
  donations: Donation[];
  onAddDonation: (newDonation: Donation) => void;
}

export const DonationSection: React.FC<DonationSectionProps> = ({ donations, onAddDonation }) => {
  const [selectedMethod, setSelectedMethod] = useState<'bKash' | 'Nagad' | 'Rocket' | 'Bank'>('bKash');
  const [donorName, setDonorName] = useState('');
  const [phone, setPhone] = useState('');
  const [amount, setAmount] = useState<number>(500);
  const [transactionId, setTransactionId] = useState('');
  const [cause, setCause] = useState('সাধারণ ফান্ড ও মানবসেবা');
  const [copiedNumber, setCopiedNumber] = useState(false);
  const [lastReceipt, setLastReceipt] = useState<Donation | null>(null);

  const paymentNumbers = {
    bKash: '01711223344 (Personal / Merchant)',
    Nagad: '01812345678 (Personal)',
    Rocket: '01911987654 (Personal)',
    Bank: 'Islami Bank Bangladesh PLC, A/C: 205011223344'
  };

  const presetAmounts = [100, 500, 1000, 2000, 5000];

  const handleCopy = (num: string) => {
    navigator.clipboard.writeText(num.split(' ')[0]);
    setCopiedNumber(true);
    setTimeout(() => setCopiedNumber(false), 2000);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!donorName || !phone || !transactionId) return;

    const receiptNo = `REC-2026-${Math.floor(1000 + Math.random() * 9000)}`;
    const newDonation: Donation = {
      id: `d${Date.now()}`,
      receiptNo,
      donorName,
      phone,
      amount,
      method: selectedMethod,
      transactionId,
      cause,
      date: new Date().toISOString().split('T')[0],
      status: 'verified'
    };

    onAddDonation(newDonation);
    setLastReceipt(newDonation);
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Title */}
      <div className="text-center space-y-2 max-w-xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-100 dark:bg-teal-950 text-teal-800 dark:text-teal-300 text-xs font-bold">
          <CreditCard className="w-4 h-4" />
          <span>অনলাইন অনুদান তহবিল</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white font-['Noto_Serif_Bengali']">
          ছাদেক মোহাম্মদ পাড়া অনুদান
        </h2>
        <p className="text-slate-600 dark:text-slate-300 text-sm">
          আপনার প্রদত্ত অনুদান সরাসরি এলাকার দুস্থ ও সামাজিক মানবিক কর্মকাণ্ডে ব্যবহৃত হয়।
        </p>
      </div>

      {/* Show Newly Generated Receipt if available */}
      {lastReceipt ? (
        <div className="max-w-md mx-auto space-y-4">
          <div className="p-3 bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 rounded-2xl font-bold text-xs flex items-center justify-center gap-2 border border-emerald-300">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>অনুদানের রসিদ সফলভাবে তৈরি হয়েছে!</span>
          </div>

          {/* Printable Receipt Card */}
          <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border-2 border-emerald-500 shadow-xl space-y-4 font-['Hind_Siliguri'] text-slate-800 dark:text-slate-200">
            <div className="text-center border-b pb-3 border-slate-100 dark:border-slate-800">
              <h3 className="text-base font-bold text-emerald-700 dark:text-emerald-400 font-['Noto_Serif_Bengali']">
                ছাদেক মোহাম্মদ পাড়া ঐক্য পরিষদ
              </h3>
              <p className="text-[11px] text-slate-500">অনুদানের অফিসিয়াল ডিজিটাল রসিদ</p>
              <span className="inline-block mt-1 text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2.5 py-0.5 rounded-full">
                রসিদ নম্বর: {lastReceipt.receiptNo}
              </span>
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500">দাতাগণের নাম:</span>
                <span className="font-bold">{lastReceipt.donorName}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500">মোবাইল নম্বর:</span>
                <span className="font-bold">{lastReceipt.phone}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500">অনুদানের পরিমাণ:</span>
                <span className="font-extrabold text-emerald-600 text-sm">৳{lastReceipt.amount.toLocaleString('bn-BD')}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500">পেমেন্ট মাধ্যম:</span>
                <span className="font-bold">{lastReceipt.method} ({lastReceipt.transactionId})</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500">খাত / বিবরণ:</span>
                <span className="font-medium">{lastReceipt.cause}</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-500">তারিখ:</span>
                <span>{lastReceipt.date}</span>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex justify-between items-center text-[10px] text-slate-400">
              <span>যাচাইকৃত রসিদ</span>
              <span className="text-emerald-600 font-bold">ঐক্য পরিষদ তহবিল</span>
            </div>
          </div>

          <div className="flex gap-2">
            <button
              onClick={() => window.print()}
              className="flex-1 py-2.5 rounded-xl bg-emerald-600 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow"
            >
              <Printer className="w-4 h-4" />
              <span>রসিদ প্রিন্ট করুন</span>
            </button>
            <button
              onClick={() => setLastReceipt(null)}
              className="py-2.5 px-4 rounded-xl bg-slate-200 dark:bg-slate-800 text-slate-800 dark:text-slate-200 font-bold text-xs"
            >
              নতুন অনুদান
            </button>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          {/* Left: Payment Method Selector & Number Copy */}
          <div className="md:col-span-5 bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <QrCode className="w-4 h-4 text-emerald-600" />
              <span>পেমেন্ট মাধ্যম বাছাই করুন</span>
            </h3>

            {/* Method Tabs */}
            <div className="grid grid-cols-2 gap-2">
              {(['bKash', 'Nagad', 'Rocket', 'Bank'] as const).map((m) => (
                <button
                  key={m}
                  onClick={() => setSelectedMethod(m)}
                  className={`p-3 rounded-2xl font-bold text-xs transition flex flex-col items-center gap-1 border ${
                    selectedMethod === m
                      ? 'bg-emerald-600 text-white border-emerald-600 shadow'
                      : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                  }`}
                >
                  <span className="text-sm">
                    {m === 'bKash' ? '💖 বিকাশ' : m === 'Nagad' ? '🟠 নগদ' : m === 'Rocket' ? '🟣 রকেট' : '🏛️ ব্যাংক'}
                  </span>
                </button>
              ))}
            </div>

            {/* Selected Number Box & QR Code */}
            <div className="bg-emerald-50 dark:bg-emerald-950/60 p-4 rounded-2xl border border-emerald-200 dark:border-emerald-800 space-y-3">
              <div className="space-y-1">
                <span className="text-[11px] font-bold text-emerald-700 dark:text-emerald-400 block uppercase">
                  {selectedMethod} নম্বর/হিসাব:
                </span>
                <p className="text-sm font-extrabold text-slate-900 dark:text-white select-all">
                  {paymentNumbers[selectedMethod]}
                </p>
              </div>

              <button
                onClick={() => handleCopy(paymentNumbers[selectedMethod])}
                className="w-full py-2 px-3 rounded-xl bg-white dark:bg-slate-900 text-emerald-700 dark:text-emerald-300 text-xs font-bold border border-emerald-300 dark:border-emerald-700 hover:bg-emerald-100 transition flex items-center justify-center gap-1.5"
              >
                {copiedNumber ? <CheckCircle2 className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                <span>{copiedNumber ? 'কপি হয়েছে!' : 'নম্বর কপি করুন'}</span>
              </button>
            </div>

            {/* QR Code Placeholder */}
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 flex flex-col items-center text-center space-y-2">
              <QrCode className="w-20 h-20 text-slate-800 dark:text-slate-200" />
              <p className="text-[11px] text-slate-500">
                {selectedMethod} অ্যাপ দিয়ে স্ক্যান করে সরাসরি টাকা পাঠান
              </p>
            </div>
          </div>

          {/* Right: Donation Form */}
          <form onSubmit={handleSubmit} className="md:col-span-7 bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Heart className="w-4 h-4 text-rose-500 fill-rose-500" />
              <span>অনুদানের বিবরণ নিশ্চিতকরণ</span>
            </h3>

            {/* Presets */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
                অনুদানের পরিমাণ (টাকায়):
              </label>
              <div className="flex flex-wrap gap-2">
                {presetAmounts.map((amt) => (
                  <button
                    key={amt}
                    type="button"
                    onClick={() => setAmount(amt)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition border ${
                      amount === amt
                        ? 'bg-amber-400 text-slate-950 border-amber-400'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                    }`}
                  >
                    ৳{amt}
                  </button>
                ))}
              </div>
            </div>

            {/* Custom Amount */}
            <div className="space-y-1">
              <input
                type="number"
                required
                value={amount}
                onChange={(e) => setAmount(Number(e.target.value))}
                placeholder="অন্যান্য পরিমাণ"
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 text-sm font-bold text-slate-900 dark:text-white outline-none"
              />
            </div>

            {/* Donor Name */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                আপনার নাম *
              </label>
              <input
                type="text"
                required
                value={donorName}
                onChange={(e) => setDonorName(e.target.value)}
                placeholder="যেমন: মোঃ জহিরুল ইসলাম / নাম প্রকাশে অনিচ্ছুক"
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 text-sm text-slate-900 dark:text-white outline-none"
              />
            </div>

            {/* Phone */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                মোবাইল নম্বর *
              </label>
              <input
                type="tel"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="017XXXXXXXX"
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 text-sm text-slate-900 dark:text-white outline-none"
              />
            </div>

            {/* Transaction ID */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                ট্রানজেকশন আইডি (TxnID) *
              </label>
              <input
                type="text"
                required
                value={transactionId}
                onChange={(e) => setTransactionId(e.target.value)}
                placeholder="যেমন: BK9281726"
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 text-sm font-mono text-slate-900 dark:text-white outline-none"
              />
            </div>

            {/* Cause */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                অনুদানের খাত
              </label>
              <select
                value={cause}
                onChange={(e) => setCause(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 text-sm text-slate-900 dark:text-white outline-none"
              >
                <option value="সাধারণ ফান্ড ও মানবসেবা">সাধারণ ফান্ড ও মানবসেবা</option>
                <option value="ত্রাণ ও জরুরি দুর্যোগ সাহায্য">ত্রাণ ও জরুরি দুর্যোগ সাহায্য</option>
                <option value="শিক্ষাবৃত্তি তহবিল">শিক্ষাবৃত্তি তহবিল</option>
                <option value="ফ্রি মেডিকেল ও ব্লাড ব্যাংক">ফ্রি মেডিকেল ও ব্লাড ব্যাংক</option>
              </select>
            </div>

            <button
              type="submit"
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-extrabold text-sm shadow hover:brightness-110 transition flex items-center justify-center gap-2"
            >
              <CreditCard className="w-4 h-4" />
              <span>অনুদানের রসিদ জেনারেট করুন</span>
            </button>
          </form>
        </div>
      )}

      {/* Verified Donation Ledger */}
      <section className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
        <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center justify-between">
          <span className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>সাম্প্রতিক অনুদান প্রদানকারীদের তালিকা</span>
          </span>
          <span className="text-xs text-emerald-600 dark:text-emerald-400 font-bold">স্বচ্ছ ও প্রকাশ্য</span>
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500">
                <th className="py-2.5 px-3">রসিদ নং</th>
                <th className="py-2.5 px-3">দাতা</th>
                <th className="py-2.5 px-3">পরিমাণ</th>
                <th className="py-2.5 px-3">পদ্ধতি</th>
                <th className="py-2.5 px-3">খাত</th>
                <th className="py-2.5 px-3">তারিখ</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {donations.map((d) => (
                <tr key={d.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                  <td className="py-2.5 px-3 font-mono font-bold text-amber-600 dark:text-amber-400">{d.receiptNo}</td>
                  <td className="py-2.5 px-3 font-bold text-slate-800 dark:text-slate-200">{d.donorName}</td>
                  <td className="py-2.5 px-3 font-black text-emerald-600">৳{d.amount.toLocaleString('bn-BD')}</td>
                  <td className="py-2.5 px-3 text-slate-600 dark:text-slate-400">{d.method}</td>
                  <td className="py-2.5 px-3 text-slate-600 dark:text-slate-400">{d.cause}</td>
                  <td className="py-2.5 px-3 text-slate-400">{d.date}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};
