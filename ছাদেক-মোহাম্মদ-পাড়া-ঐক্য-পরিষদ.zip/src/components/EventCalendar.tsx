import React, { useState } from 'react';
import { Calendar as CalendarIcon, Clock, MapPin, CheckCircle2, ChevronLeft, ChevronRight } from 'lucide-react';
import { EventItem } from '../types';

interface EventCalendarProps {
  events: EventItem[];
}

export const EventCalendar: React.FC<EventCalendarProps> = ({ events }) => {
  const [currentMonth, setCurrentMonth] = useState('আগস্ট ২০২৬');

  return (
    <div className="space-y-6 pb-12">
      {/* Title */}
      <div className="text-center space-y-2 max-w-xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-sky-100 dark:bg-sky-950 text-sky-800 dark:text-sky-300 text-xs font-bold">
          <CalendarIcon className="w-4 h-4" />
          <span>ইভেন্ট ও সভার ক্যালেন্ডার</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white font-['Noto_Serif_Bengali']">
          আগামী সকল কার্যক্রম সূচি
        </h2>
        <p className="text-slate-600 dark:text-slate-300 text-sm">
          ছাদেক মোহাম্মদ পাড়া ঐক্য পরিষদের বার্ষিক ও মাসিক সভা এবং অনুষ্ঠানসমূহ
        </p>
      </div>

      {/* Calendar Month Header */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm flex items-center justify-between">
        <button
          onClick={() => setCurrentMonth('জুলাই ২০২৬')}
          className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 transition"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>

        <h3 className="text-lg font-bold text-slate-900 dark:text-white font-['Noto_Serif_Bengali']">
          {currentMonth}
        </h3>

        <button
          onClick={() => setCurrentMonth('সেপ্টেম্বর ২০২৬')}
          className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 transition"
        >
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>

      {/* Events List Cards */}
      <div className="space-y-4">
        {events.map((evt) => (
          <div
            key={evt.id}
            className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200/80 dark:border-slate-800 shadow-sm hover:shadow-md transition flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
          >
            <div className="flex items-start gap-4">
              {/* Date Badge */}
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-emerald-500 to-sky-500 text-slate-950 font-black p-2 flex flex-col items-center justify-center shrink-0 shadow-md">
                <span className="text-[10px] uppercase font-bold text-slate-900 tracking-wider">{evt.category}</span>
                <span className="text-base font-extrabold leading-tight">{evt.date.slice(-5)}</span>
              </div>

              {/* Event Content */}
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-full bg-sky-100 dark:bg-sky-950 text-sky-800 dark:text-sky-300 text-[11px] font-bold">
                    {evt.status === 'upcoming' ? 'আসন্ন অনুষ্ঠান' : 'সম্পন্ন'}
                  </span>
                  <span className="text-slate-400 text-xs">তারিখ: {evt.date}</span>
                </div>

                <h3 className="text-lg font-bold text-slate-900 dark:text-white font-['Noto_Serif_Bengali']">
                  {evt.title}
                </h3>

                <p className="text-xs text-slate-600 dark:text-slate-300">
                  {evt.description}
                </p>

                <div className="flex flex-wrap items-center gap-4 text-xs text-slate-500 pt-1">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-sky-600" />
                    <span>{evt.time}</span>
                  </span>
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-emerald-600" />
                    <span>{evt.location}</span>
                  </span>
                </div>
              </div>
            </div>

            <button
              onClick={() => alert(`আপনি "${evt.title}" ইভেন্টে অংশগ্রহণের আগ্রহ প্রকাশ করেছেন।`)}
              className="w-full md:w-auto px-5 py-2.5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow transition shrink-0"
            >
              অংশগ্রহণ করব
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};
