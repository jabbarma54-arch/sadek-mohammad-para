import React, { useRef } from 'react';
import { ShieldCheck, HeartHandshake, Download, Printer, QrCode, CheckCircle2 } from 'lucide-react';
import { Member } from '../types';

interface DigitalIdCardProps {
  member: Member;
}

export const DigitalIdCard: React.FC<DigitalIdCardProps> = ({ member }) => {
  const cardRef = useRef<HTMLDivElement>(null);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="flex flex-col items-center space-y-6">
      {/* Printable ID Card Container */}
      <div 
        ref={cardRef}
        className="w-full max-w-sm rounded-3xl overflow-hidden shadow-2xl bg-gradient-to-br from-emerald-900 via-emerald-800 to-sky-950 text-white border-2 border-emerald-400/40 relative print:shadow-none print:m-0"
      >
        {/* Background Decorative Pattern */}
        <div className="absolute -top-12 -right-12 w-44 h-44 rounded-full bg-emerald-400/10 blur-2xl pointer-events-none"></div>
        <div className="absolute -bottom-12 -left-12 w-44 h-44 rounded-full bg-sky-400/10 blur-2xl pointer-events-none"></div>

        {/* Header Ribbon */}
        <div className="bg-emerald-950/80 px-4 py-3 border-b border-emerald-500/30 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-emerald-400 to-sky-400 p-0.5 flex items-center justify-center">
              <div className="w-full h-full rounded-[10px] bg-emerald-950 flex items-center justify-center">
                <ShieldCheck className="w-5 h-5 text-emerald-400" />
              </div>
            </div>
            <div>
              <h3 className="text-xs font-bold font-['Noto_Serif_Bengali'] text-white">ছাদেক মোহাম্মদ পাড়া ঐক্য পরিষদ</h3>
              <p className="text-[9px] text-emerald-300 font-medium">ডিজিটাল সদস্য পরিচয়পত্র (ID CARD)</p>
            </div>
          </div>

          <span className="text-[9px] font-extrabold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
            {member.role === 'executive' ? 'কার্যকরী সদস্য' : 'নিবন্ধিত সদস্য'}
          </span>
        </div>

        {/* Card Body */}
        <div className="p-5 space-y-4">
          <div className="flex items-start gap-4">
            {/* Photo */}
            <div className="relative shrink-0">
              <img
                src={member.photoUrl || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop&q=80'}
                alt={member.nameBn}
                className="w-24 h-28 rounded-2xl object-cover border-2 border-amber-400 shadow-md"
              />
              <span className="absolute -bottom-1 -right-1 bg-emerald-500 text-slate-950 text-[10px] font-black px-1.5 py-0.5 rounded-md">
                {member.bloodGroup || 'O+'}
              </span>
            </div>

            {/* Member Details */}
            <div className="space-y-1.5 text-xs flex-1">
              <div>
                <span className="text-[9px] text-emerald-300 uppercase tracking-wider block">আইডি নম্বর:</span>
                <span className="font-extrabold text-amber-300 text-sm tracking-wide">{member.memberNo}</span>
              </div>

              <div>
                <h4 className="font-bold text-sm text-white font-['Noto_Serif_Bengali']">{member.nameBn}</h4>
                <p className="text-[11px] text-emerald-200 font-medium">{member.nameEn}</p>
              </div>

              <div className="text-[11px] text-slate-200 space-y-0.5 pt-1">
                <p><span className="text-emerald-300 font-medium">মোবাইল:</span> {member.phone}</p>
                {member.occupation && <p><span className="text-emerald-300 font-medium">পেশা:</span> {member.occupation}</p>}
                <p className="truncate"><span className="text-emerald-300 font-medium">ঠিকানা:</span> {member.address}</p>
              </div>
            </div>
          </div>

          {/* Verification & Barcode / QR Section */}
          <div className="pt-3 border-t border-emerald-500/30 flex items-center justify-between text-xs">
            <div className="space-y-1">
              <div className="flex items-center gap-1 text-[10px] text-emerald-300 font-semibold">
                <CheckCircle2 className="w-3.5 h-3.5 text-amber-400" />
                <span>যাচাইকৃত বৈধ সদস্য</span>
              </div>
              <p className="text-[9px] text-slate-300">যোগদান: {member.joinDate}</p>
            </div>

            {/* Simulated QR Code */}
            <div className="bg-white p-1.5 rounded-xl text-slate-950 flex flex-col items-center shadow">
              <QrCode className="w-9 h-9" />
              <span className="text-[8px] font-mono font-bold tracking-tight">VERIFIED</span>
            </div>
          </div>
        </div>

        {/* Card Footer Slogan */}
        <div className="bg-emerald-950 text-center py-1.5 px-3 border-t border-emerald-500/20 text-[10px] text-emerald-300 font-medium">
          "ঐক্যে শক্তি, মানবতায় সেবা"
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex items-center gap-3 print:hidden">
        <button
          onClick={handlePrint}
          className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow transition flex items-center gap-2"
        >
          <Printer className="w-4 h-4" />
          <span>কার্ড প্রিন্ট / PDF সংরক্ষণ</span>
        </button>
      </div>
    </div>
  );
};
