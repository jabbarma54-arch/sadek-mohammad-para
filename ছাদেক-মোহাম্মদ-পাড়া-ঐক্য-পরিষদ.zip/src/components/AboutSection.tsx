import React from 'react';
import { ShieldCheck, HeartHandshake, Target, History, Sparkles, CheckCircle2, Award } from 'lucide-react';

export const AboutSection: React.FC = () => {
  return (
    <div className="space-y-8 pb-12">
      {/* Title Header */}
      <div className="text-center space-y-2 max-w-2xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 text-xs font-bold">
          <ShieldCheck className="w-4 h-4" />
          <span>আমাদের পরিচিতি ও অঙ্গীকার</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white font-['Noto_Serif_Bengali']">
          ছাদেক মোহাম্মদ পাড়া ঐক্য পরিষদ
        </h2>
        <p className="text-slate-600 dark:text-slate-300 text-sm">
          ঐক্য, সামাজিক মেলবন্ধন, শিক্ষা ও মানবতার কল্যাণে আত্মনিবেদিত একটি সামাজিক অরাজনৈতিক পরিষদ।
        </p>
      </div>

      {/* Grid Cards: Vision, Mission, History, Values */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* About Intro */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-emerald-100 dark:bg-emerald-950 flex items-center justify-center text-emerald-600 dark:text-emerald-400">
            <HeartHandshake className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-bold text-slate-900 dark:text-white font-['Noto_Serif_Bengali']">
            পরিচিতি (Introduction)
          </h3>
          <p className="text-slate-600 dark:text-slate-300 text-sm leading-relaxed">
            ছাদেক মোহাম্মদ পাড়া ঐক্য পরিষদ এলাকার সম্মানিত ব্যক্তিবর্গ, যুবসমাজ ও শুভানুধ্যায়ীদের সম্মিলিত প্রচেষ্টায় প্রতিষ্ঠিত একটি সেবামূলক সংগঠন। আমাদের মূল শক্তি পারস্পরিক ভ্রাতৃত্ব ও সমাজ সংস্কার।
          </p>
        </div>

        {/* Goal & Vision */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-sky-100 dark:bg-sky-950 flex items-center justify-center text-sky-600 dark:text-sky-400">
            <Target className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-bold text-slate-900 dark:text-white font-['Noto_Serif_Bengali']">
            লক্ষ্য ও উদ্দেশ্য (Objectives)
          </h3>
          <ul className="space-y-2 text-sm text-slate-600 dark:text-slate-300">
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
              <span>এলাকার দরিদ্র ও অসহায় মানুষের মাঝে মানবিক ও চিকিৎসা সহায়তা পৌঁছানো।</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
              <span>ঝরে পড়া ও দুস্থ শিক্ষার্থীদের শিক্ষাবৃত্তি ও শিক্ষা উপকরণ বিতরণ।</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
              <span>জরুরি রক্তদান নেটওয়ার্ক গড়ে তুলে ব্লাড ব্যাংকের মাধ্যমে জীবন রক্ষা করা।</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
              <span>সামাজিক অপরাধ, মাদক ও পরিবেশ সচেতনতামূলক প্রচারণা চালানো।</span>
            </li>
          </ul>
        </div>

        {/* History */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-amber-100 dark:bg-amber-950 flex items-center justify-center text-amber-600 dark:text-amber-400">
            <History className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-bold text-slate-900 dark:text-white font-['Noto_Serif_Bengali']">
            আমাদের ইতিহাস (History)
          </h3>
          <p className="text-slate-600 dark:text-slate-300 text-sm leading-relaxed">
            ২০২২ সালে স্থানীয় কয়েকজন নিবেদিতপ্রাণ যুবক ও মুরুব্বিদের হাত ধরে ঐক্য পরিষদের যাত্রা শুরু হয়। শুরু থেকে আজ অব্দি প্রাকৃতিক দুর্যোগে সহায়তা, ঈদ উপহার প্রদান, ফ্রি ব্লাড গ্রুপিং এবং ড্রেন পরিষ্কারের মতো অজস্র কাজ সফলভাবে সম্পাদিত হয়েছে।
          </p>
        </div>

        {/* Values */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-rose-100 dark:bg-rose-950 flex items-center justify-center text-rose-600 dark:text-rose-400">
            <Award className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-bold text-slate-900 dark:text-white font-['Noto_Serif_Bengali']">
            মূলনীতিসমূহ (Core Values)
          </h3>
          <div className="grid grid-cols-2 gap-3 pt-1">
            <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700">
              <span className="font-bold text-emerald-600 dark:text-emerald-400 text-sm block">১. সততা ও স্বচ্ছতা</span>
              <span className="text-[11px] text-slate-500">অনুদানের সুনির্দিষ্ট হিসাব</span>
            </div>
            <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700">
              <span className="font-bold text-emerald-600 dark:text-emerald-400 text-sm block">২. অরাজনৈতিকতা</span>
              <span className="text-[11px] text-slate-500">শুধুই জনকল্যাণ কেন্দ্রিক</span>
            </div>
            <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700">
              <span className="font-bold text-emerald-600 dark:text-emerald-400 text-sm block">৩. ভ্রাতৃত্ববোধ</span>
              <span className="text-[11px] text-slate-500">সকলের বিপদে পাশে থাকা</span>
            </div>
            <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700">
              <span className="font-bold text-emerald-600 dark:text-emerald-400 text-sm block">৪. তরুণ নেতৃত্ব</span>
              <span className="text-[11px] text-slate-500">উদ্ভাবন ও গঠনমূলক কাজ</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
