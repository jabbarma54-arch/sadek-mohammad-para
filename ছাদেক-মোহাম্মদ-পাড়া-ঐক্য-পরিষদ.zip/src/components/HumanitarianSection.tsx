import React, { useState } from 'react';
import { Heart, Droplets, Phone, Search, PlusCircle, CheckCircle2, ShieldCheck, HelpCircle } from 'lucide-react';
import { Activity } from '../types';

interface HumanitarianSectionProps {
  activities: Activity[];
}

interface BloodDonor {
  id: string;
  name: string;
  group: string;
  phone: string;
  area: string;
  lastDonated: string;
}

export const HumanitarianSection: React.FC<HumanitarianSectionProps> = ({ activities }) => {
  const [selectedGroup, setSelectedGroup] = useState<string>('সবগুলো');
  const [showRequestForm, setShowRequestForm] = useState(false);
  const [requestSubmitted, setRequestSubmitted] = useState(false);

  const bloodGroups = ['সবগুলো', 'A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'];

  const donors: BloodDonor[] = [
    { id: 'bd1', name: 'মোঃ আরিফুর রহমান', group: 'A+', phone: '01822233344', area: 'মধ্য পাড়া', lastDonated: '৩ মাস আগে' },
    { id: 'bd2', name: 'কাজী কামরুল হাসান', group: 'B+', phone: '01933344455', area: 'দক্ষিণ পাড়া', lastDonated: '৪ মাস আগে' },
    { id: 'bd3', name: 'মোঃ তানভীর আহমেদ', group: 'O+', phone: '01612998877', area: 'উত্তর পাড়া', lastDonated: '২ মাস আগে' },
    { id: 'bd4', name: 'ইঞ্জিনিয়ার শাহাদাত', group: 'AB+', phone: '01711987654', area: 'পশ্চিম পাড়া', lastDonated: '৬ মাস আগে' },
    { id: 'bd5', name: 'মোঃ রিয়াজ উদ্দিন', group: 'O-', phone: '01815554433', area: 'মধ্য পাড়া', lastDonated: '৫ মাস আগে' }
  ];

  const filteredDonors = donors.filter(d => selectedGroup === 'সবগুলো' || d.group === selectedGroup);

  return (
    <div className="space-y-8 pb-12">
      {/* Title */}
      <div className="text-center space-y-2 max-w-xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-100 dark:bg-rose-950 text-rose-800 dark:text-rose-300 text-xs font-bold">
          <Heart className="w-4 h-4 text-rose-500 fill-rose-500" />
          <span>মানবিক কার্যক্রম ও রক্তদান</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white font-['Noto_Serif_Bengali']">
          সেবায় আত্মনিবেদিত ঐক্য পরিষদ
        </h2>
        <p className="text-slate-600 dark:text-slate-300 text-sm">
          রক্তদান, দুর্যোগকালীন সহায়তা, শীতবস্ত্র বিতরণ ও চিকিৎসা সহায়তা সেবাসমূহ
        </p>
      </div>

      {/* Emergency Blood Donor Directory Section */}
      <section className="bg-gradient-to-br from-rose-900 via-rose-800 to-rose-950 text-white rounded-3xl p-6 shadow-xl border border-rose-700 space-y-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-white/10 rounded-2xl border border-white/20">
              <Droplets className="w-8 h-8 text-rose-300 animate-pulse" />
            </div>
            <div>
              <h3 className="text-xl font-extrabold font-['Noto_Serif_Bengali']">
                জরুরি রক্তের গ্রুপ ডিরেক্টরি
              </h3>
              <p className="text-xs text-rose-200">
                আমাদের পাড়ার নিবন্ধিত স্বেচ্ছাসেবী রক্তদাতাদের তালিকা থেকে যোগাযোগ করুন
              </p>
            </div>
          </div>

          <button
            onClick={() => setShowRequestForm(!showRequestForm)}
            className="px-4 py-2.5 rounded-xl bg-amber-400 text-slate-950 font-extrabold text-xs shadow hover:bg-amber-300 transition flex items-center justify-center gap-1.5"
          >
            <HelpCircle className="w-4 h-4" />
            <span>জরুরি রক্তের আবেদন করুন</span>
          </button>
        </div>

        {/* Blood Group Filter */}
        <div className="flex flex-wrap gap-1.5 pt-2">
          {bloodGroups.map((bg) => (
            <button
              key={bg}
              onClick={() => setSelectedGroup(bg)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition border ${
                selectedGroup === bg
                  ? 'bg-white text-rose-900 border-white font-black'
                  : 'bg-white/10 text-rose-100 border-white/20 hover:bg-white/20'
              }`}
            >
              {bg}
            </button>
          ))}
        </div>

        {/* Emergency Request Form Modal/Box */}
        {showRequestForm && (
          <div className="p-4 bg-white text-slate-900 rounded-2xl shadow-lg space-y-3">
            <h4 className="text-sm font-bold text-rose-900 flex items-center gap-1.5">
              <Droplets className="w-4 h-4 text-rose-600" />
              <span>জরুরি রক্তের প্রয়োজনে ফর্ম পূরণ করুন:</span>
            </h4>

            {requestSubmitted ? (
              <div className="p-3 bg-emerald-100 text-emerald-800 rounded-xl text-xs font-bold flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>আপনার আবেদন গৃহীত হয়েছে! স্বেচ্ছাসেবক দল খুব শীঘ্রই আপনার সাথে যোগাযোগ করবে।</span>
              </div>
            ) : (
              <form onSubmit={(e) => { e.preventDefault(); setRequestSubmitted(true); }} className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <input
                  type="text"
                  required
                  placeholder="রোগীর নাম ও স্থান"
                  className="bg-slate-50 border rounded-xl p-2.5 text-xs outline-none"
                />
                <input
                  type="text"
                  required
                  placeholder="রক্তের গ্রুপ (যেমন: O+)"
                  className="bg-slate-50 border rounded-xl p-2.5 text-xs outline-none"
                />
                <input
                  type="tel"
                  required
                  placeholder="যোগাযোগের নম্বর"
                  className="bg-slate-50 border rounded-xl p-2.5 text-xs outline-none"
                />
                <button
                  type="submit"
                  className="sm:col-span-3 py-2 bg-rose-600 text-white font-bold rounded-xl text-xs hover:bg-rose-500 transition"
                >
                  আবেদন জমা দিন
                </button>
              </form>
            )}
          </div>
        )}

        {/* Donors Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 pt-2">
          {filteredDonors.map((d) => (
            <div
              key={d.id}
              className="bg-white/10 backdrop-blur-md rounded-2xl p-3.5 border border-white/20 flex items-center justify-between gap-3"
            >
              <div className="space-y-0.5">
                <div className="flex items-center gap-2">
                  <span className="w-7 h-7 rounded-lg bg-rose-500 text-white font-extrabold text-xs flex items-center justify-center shadow">
                    {d.group}
                  </span>
                  <h4 className="text-xs font-bold text-white">{d.name}</h4>
                </div>
                <p className="text-[10px] text-rose-200">📍 {d.area} • শেষ রক্তদান: {d.lastDonated}</p>
              </div>

              <a
                href={`tel:${d.phone}`}
                className="p-2 rounded-xl bg-white text-rose-900 hover:bg-rose-100 transition shadow shrink-0"
                title="কল দিন"
              >
                <Phone className="w-4 h-4" />
              </a>
            </div>
          ))}
        </div>
      </section>

      {/* Humanitarian Activities List */}
      <section className="space-y-4">
        <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-emerald-600" />
          <span>আমাদের সকল পরিচালিত মানবিক প্রকল্পসমূহ</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {activities.map((act) => (
            <div
              key={act.id}
              className="bg-white dark:bg-slate-900 rounded-3xl overflow-hidden border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-col sm:flex-row"
            >
              <img
                src={act.imageUrl}
                alt={act.title}
                className="w-full sm:w-48 h-44 object-cover shrink-0"
              />
              <div className="p-4 space-y-2 flex-1">
                <span className="text-[10px] font-extrabold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800">
                  {act.category}
                </span>
                <h4 className="text-base font-bold text-slate-900 dark:text-white font-['Noto_Serif_Bengali']">
                  {act.title}
                </h4>
                <p className="text-xs text-slate-600 dark:text-slate-300 line-clamp-2">
                  {act.description}
                </p>
                <div className="pt-2 text-[11px] text-slate-500 flex justify-between border-t border-slate-100 dark:border-slate-800">
                  <span>তারিখ: {act.date}</span>
                  <span className="font-bold text-emerald-600">উপকারভোগী: {act.beneficiariesCount} জন</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
