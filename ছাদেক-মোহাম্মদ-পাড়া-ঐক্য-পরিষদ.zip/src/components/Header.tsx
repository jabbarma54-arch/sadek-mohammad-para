import React, { useState } from 'react';
import { 
  ShieldCheck, 
  HeartHandshake, 
  Smartphone, 
  Monitor, 
  Moon, 
  Sun, 
  Search, 
  Bell, 
  UserCheck, 
  ShieldAlert,
  Globe,
  X
} from 'lucide-react';
import { Language } from '../types';

interface HeaderProps {
  language: Language;
  onToggleLanguage: () => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
  isMobileFrame: boolean;
  onToggleMobileFrame: () => void;
  isAdmin: boolean;
  onToggleAdmin: () => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onOpenNotifications: () => void;
  activeMemberCount: number;
  unreadNoticesCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  language,
  onToggleLanguage,
  darkMode,
  onToggleDarkMode,
  isMobileFrame,
  onToggleMobileFrame,
  isAdmin,
  onToggleAdmin,
  searchQuery,
  onSearchChange,
  onOpenNotifications,
  activeMemberCount,
  unreadNoticesCount
}) => {
  const [showSearch, setShowSearch] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-emerald-800 dark:bg-slate-900 text-white shadow-md transition-colors border-b border-emerald-700/50 dark:border-slate-800">
      {/* Top Bar with Admin Switcher & Utilities */}
      <div className="bg-emerald-900/90 dark:bg-slate-950 px-4 py-1.5 text-xs text-emerald-100 flex items-center justify-between border-b border-emerald-800/60 dark:border-slate-800">
        <div className="flex items-center gap-3">
          <span className="hidden sm:inline-block font-medium">📍 ছাদেক মোহাম্মদ পাড়া, ওয়ার্ড নং ৪</span>
          <span className="inline-flex items-center gap-1 text-emerald-300">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            সদস্য: {activeMemberCount} জন
          </span>
        </div>

        <div className="flex items-center gap-2">
          {/* Viewport Frame Mode Toggle */}
          <button
            onClick={onToggleMobileFrame}
            title={isMobileFrame ? "ফুল-স্ক্রিন মোড" : "মোবাইল ফ্রেম মোড"}
            className="flex items-center gap-1 px-2 py-0.5 rounded bg-emerald-800/80 hover:bg-emerald-700 dark:bg-slate-800 text-emerald-100 dark:text-slate-200 transition text-[11px]"
          >
            {isMobileFrame ? (
              <>
                <Monitor className="w-3 h-3 text-sky-300" />
                <span className="hidden xs:inline">ওয়েব ভিউ</span>
              </>
            ) : (
              <>
                <Smartphone className="w-3 h-3 text-emerald-300" />
                <span className="hidden xs:inline">মোবাইল অ্যাপ ভিউ</span>
              </>
            )}
          </button>

          {/* Dark Mode */}
          <button
            onClick={onToggleDarkMode}
            className="p-1 rounded bg-emerald-800/80 hover:bg-emerald-700 dark:bg-slate-800 text-amber-300 transition"
            title="ডার্ক মোড টগল"
          >
            {darkMode ? <Sun className="w-3.5 h-3.5" /> : <Moon className="w-3.5 h-3.5" />}
          </button>

          {/* Language Switch */}
          <button
            onClick={onToggleLanguage}
            className="flex items-center gap-1 px-2 py-0.5 rounded bg-emerald-800/80 hover:bg-emerald-700 dark:bg-slate-800 font-semibold text-[11px]"
          >
            <Globe className="w-3 h-3 text-sky-300" />
            <span>{language === 'bn' ? 'English' : 'বাংলা'}</span>
          </button>

          {/* Admin Toggle */}
          <button
            onClick={onToggleAdmin}
            className={`flex items-center gap-1 px-2 py-0.5 rounded font-bold text-[11px] transition ${
              isAdmin 
                ? 'bg-amber-400 text-slate-950 shadow-sm' 
                : 'bg-emerald-950/80 text-amber-300 hover:bg-emerald-950'
            }`}
          >
            <ShieldAlert className="w-3 h-3" />
            <span>{isAdmin ? 'এডমিন প্যানেল (চালু)' : 'এডমিন'}</span>
          </button>
        </div>
      </div>

      {/* Main Header Banner */}
      <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between gap-3">
        {/* Logo & Organization Name */}
        <div className="flex items-center gap-3">
          <div className="relative group">
            <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-2xl bg-gradient-to-tr from-emerald-500 via-teal-400 to-sky-400 p-0.5 shadow-md flex items-center justify-center">
              <div className="w-full h-full rounded-[14px] bg-emerald-950 flex items-center justify-center text-emerald-300">
                <div className="relative flex items-center justify-center">
                  <ShieldCheck className="w-6 h-6 text-emerald-400" />
                  <HeartHandshake className="w-4 h-4 text-sky-300 absolute -bottom-1 -right-1" />
                </div>
              </div>
            </div>
          </div>

          <div>
            <h1 className="text-lg sm:text-xl font-bold font-['Noto_Serif_Bengali'] text-white leading-tight flex items-center gap-1.5">
              <span>{language === 'bn' ? 'ছাদেক মোহাম্মদ পাড়া ঐক্য পরিষদ' : 'Sadek Mohammad Para Unity Council'}</span>
            </h1>
            <p className="text-xs text-emerald-200/90 font-medium tracking-wide flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span>
              <span>{language === 'bn' ? 'ঐক্যে শক্তি, মানবতায় সেবা' : 'Strength in Unity, Service in Humanity'}</span>
            </p>
          </div>
        </div>

        {/* Right Action Icons (Search, Notifications) */}
        <div className="flex items-center gap-2">
          {/* Quick Search */}
          <button
            onClick={() => setShowSearch(!showSearch)}
            className="p-2 rounded-xl bg-emerald-700/60 hover:bg-emerald-700 dark:bg-slate-800 text-emerald-100 transition"
            title="খুঁজুন"
          >
            <Search className="w-5 h-5" />
          </button>

          {/* Push Notification Button */}
          <button
            onClick={onOpenNotifications}
            className="relative p-2 rounded-xl bg-emerald-700/60 hover:bg-emerald-700 dark:bg-slate-800 text-emerald-100 transition"
            title="নোটিফিকেশন"
          >
            <Bell className="w-5 h-5" />
            {unreadNoticesCount > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-rose-500 text-white text-[10px] font-extrabold flex items-center justify-center animate-bounce shadow">
                {unreadNoticesCount}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Expandable Search Input Bar */}
      {showSearch && (
        <div className="bg-emerald-900/95 dark:bg-slate-950 px-4 py-2 border-t border-emerald-700/50 transition-all">
          <div className="max-w-xl mx-auto flex items-center gap-2">
            <Search className="w-4 h-4 text-emerald-300" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="নোটিশ, সদস্য, রক্তদান বা ইভেন্ট খুঁজুন..."
              className="w-full bg-emerald-950/80 dark:bg-slate-900 text-white placeholder-emerald-300/70 text-sm rounded-lg px-3 py-1.5 outline-none border border-emerald-600/50 focus:border-amber-400"
              autoFocus
            />
            {searchQuery && (
              <button
                onClick={() => onSearchChange('')}
                className="text-xs text-emerald-300 hover:text-white p-1"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
