import React from 'react';
import { Users, Phone, MessageSquare, ShieldCheck, Mail } from 'lucide-react';
import { CommitteeMember } from '../types';

interface CommitteeSectionProps {
  committee: CommitteeMember[];
}

export const CommitteeSection: React.FC<CommitteeSectionProps> = ({ committee }) => {
  return (
    <div className="space-y-6 pb-12">
      {/* Title */}
      <div className="text-center space-y-2 max-w-xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 text-xs font-bold">
          <Users className="w-4 h-4" />
          <span>কার্যকারী পরিচালনা পর্ষদ</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white font-['Noto_Serif_Bengali']">
          আমাদের কমিটি পরিচিতি
        </h2>
        <p className="text-slate-600 dark:text-slate-300 text-sm">
          ছাদেক মোহাম্মদ পাড়া ঐক্য পরিষদের ২০২৫-২০২৬ মেয়াদের সম্মানীত প্রতিনিধি দল
        </p>
      </div>

      {/* Committee Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {committee.map((member) => (
          <div
            key={member.id}
            className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200/80 dark:border-slate-800 shadow-sm hover:shadow-md transition flex flex-col items-center text-center space-y-3 relative group"
          >
            {/* Designation Tag */}
            <span className="px-3 py-1 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 text-xs font-extrabold border border-emerald-200 dark:border-emerald-800">
              {member.designation}
            </span>

            {/* Photo */}
            <div className="relative">
              <img
                src={member.photoUrl}
                alt={member.name}
                className="w-28 h-28 rounded-2xl object-cover shadow-md border-2 border-emerald-500/80 group-hover:scale-105 transition duration-300"
              />
              <div className="absolute -bottom-1 -right-1 p-1 bg-emerald-600 text-white rounded-full">
                <ShieldCheck className="w-3.5 h-3.5" />
              </div>
            </div>

            {/* Details */}
            <div className="space-y-1">
              <h3 className="text-base font-bold text-slate-900 dark:text-white font-['Noto_Serif_Bengali']">
                {member.name}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                ছাদেক মোহাম্মদ পাড়া ঐক্য পরিষদ
              </p>
            </div>

            {/* Actions: Phone & WhatsApp */}
            <div className="pt-2 w-full flex items-center justify-center gap-2">
              <a
                href={`tel:${member.phone}`}
                className="flex-1 py-2 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold transition flex items-center justify-center gap-1.5"
              >
                <Phone className="w-3.5 h-3.5 text-emerald-600" />
                <span>কল</span>
              </a>

              <a
                href={`https://wa.me/${member.phone.replace(/[^0-9]/g, '')}`}
                target="_blank"
                rel="noreferrer"
                className="flex-1 py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition flex items-center justify-center gap-1.5 shadow-sm"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>WhatsApp</span>
              </a>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
