import React from 'react';
import { 
  Home, 
  Info, 
  Users, 
  UserPlus, 
  Heart, 
  Bell, 
  Calendar, 
  Image as ImageIcon, 
  MessageSquare, 
  Phone, 
  CreditCard,
  IdCard,
  ShieldAlert
} from 'lucide-react';

export type TabType = 
  | 'home' 
  | 'about' 
  | 'committee' 
  | 'register' 
  | 'idcard' 
  | 'donation' 
  | 'notice' 
  | 'humanitarian' 
  | 'events' 
  | 'gallery' 
  | 'feedback' 
  | 'contact'
  | 'admin';

interface NavigationProps {
  activeTab: TabType;
  onSelectTab: (tab: TabType) => void;
  unreadNoticesCount: number;
  isAdmin: boolean;
}

export const Navigation: React.FC<NavigationProps> = ({
  activeTab,
  onSelectTab,
  unreadNoticesCount,
  isAdmin
}) => {
  const primaryTabs: { id: TabType; label: string; icon: React.ReactNode; badge?: number }[] = [
    { id: 'home', label: 'হোম', icon: <Home className="w-4 h-4" /> },
    { id: 'about', label: 'আমাদের সম্পর্কে', icon: <Info className="w-4 h-4" /> },
    { id: 'committee', label: 'কমিটি', icon: <Users className="w-4 h-4" /> },
    { id: 'register', label: 'সদস্য নিবন্ধন', icon: <UserPlus className="w-4 h-4" /> },
    { id: 'idcard', label: 'ডিজিটাল আইডি কার্ড', icon: <IdCard className="w-4 h-4" /> },
    { id: 'donation', label: 'অনুদান', icon: <CreditCard className="w-4 h-4" /> },
    { id: 'notice', label: 'নোটিশ', icon: <Bell className="w-4 h-4" />, badge: unreadNoticesCount },
    { id: 'humanitarian', label: 'মানবিক কার্যক্রম', icon: <Heart className="w-4 h-4" /> },
    { id: 'events', label: 'ইভেন্ট', icon: <Calendar className="w-4 h-4" /> },
    { id: 'gallery', label: 'গ্যালারি', icon: <ImageIcon className="w-4 h-4" /> },
    { id: 'feedback', label: 'মতামত', icon: <MessageSquare className="w-4 h-4" /> },
    { id: 'contact', label: 'যোগাযোগ', icon: <Phone className="w-4 h-4" /> }
  ];

  if (isAdmin) {
    primaryTabs.push({ id: 'admin', label: 'এডমিন ড্যাশবোর্ড', icon: <ShieldAlert className="w-4 h-4" /> });
  }

  // Mobile Bottom Bar Tabs (5 key items)
  const mobileBottomTabs: { id: TabType; label: string; icon: React.ReactNode; badge?: number }[] = [
    { id: 'home', label: 'হোম', icon: <Home className="w-5 h-5" /> },
    { id: 'notice', label: 'নোটিশ', icon: <Bell className="w-5 h-5" />, badge: unreadNoticesCount },
    { id: 'register', label: 'নিবন্ধন', icon: <UserPlus className="w-5 h-5" /> },
    { id: 'idcard', label: 'আইডি কার্ড', icon: <IdCard className="w-5 h-5" /> },
    { id: 'donation', label: 'অনুদান', icon: <CreditCard className="w-5 h-5" /> }
  ];

  return (
    <>
      {/* Desktop Main Navigation Bar */}
      <nav className="hidden md:block bg-emerald-900/90 dark:bg-slate-950 border-b border-emerald-800 dark:border-slate-800 sticky top-[69px] z-30 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 overflow-x-auto no-scrollbar">
          <div className="flex items-center space-x-1 py-1.5 min-w-max">
            {primaryTabs.map((tab) => {
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => onSelectTab(tab.id)}
                  className={`relative flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all whitespace-nowrap ${
                    isActive
                      ? 'bg-gradient-to-r from-emerald-500 to-sky-500 text-slate-950 shadow-md font-bold scale-[1.02]'
                      : 'text-emerald-100 hover:bg-emerald-800/60 dark:hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  <span>{tab.icon}</span>
                  <span>{tab.label}</span>
                  {tab.badge !== undefined && tab.badge > 0 && (
                    <span className="ml-1 px-1.5 py-0.2 rounded-full bg-rose-500 text-white text-[10px] font-extrabold">
                      {tab.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </nav>

      {/* Mobile App Bottom Navigation Navigation Bar */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 shadow-lg px-2 py-1.5 flex items-center justify-around">
        {mobileBottomTabs.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onSelectTab(tab.id)}
              className={`relative flex flex-col items-center justify-center py-1 px-2.5 rounded-xl transition-all ${
                isActive
                  ? 'text-emerald-600 dark:text-emerald-400 font-bold scale-105'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              <div className="relative">
                {tab.icon}
                {tab.badge !== undefined && tab.badge > 0 && (
                  <span className="absolute -top-1 -right-2 w-4 h-4 rounded-full bg-rose-500 text-white text-[9px] font-extrabold flex items-center justify-center">
                    {tab.badge}
                  </span>
                )}
              </div>
              <span className="text-[10px] mt-0.5 tracking-tight">{tab.label}</span>
            </button>
          );
        })}
      </div>
    </>
  );
};
