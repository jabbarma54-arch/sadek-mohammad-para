import React from 'react';
import { motion } from 'motion/react';
import { ShieldCheck, HeartHandshake, Sparkles } from 'lucide-react';

interface SplashScreenProps {
  onFinish: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onFinish }) => {
  return (
    <motion.div
      initial={{ opacity: 1 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.6 }}
      className="fixed inset-0 z-50 flex flex-col items-center justify-between bg-gradient-to-br from-emerald-900 via-emerald-800 to-sky-900 text-white p-6"
    >
      <div className="w-full flex justify-end">
        <button
          onClick={onFinish}
          className="text-xs px-3 py-1.5 rounded-full bg-white/10 hover:bg-white/20 transition backdrop-blur-md text-emerald-100 border border-white/10 flex items-center gap-1"
        >
          <span>এড়িয়ে যান</span>
          <span>→</span>
        </button>
      </div>

      <div className="flex flex-col items-center text-center max-w-sm my-auto">
        {/* Crest Logo Badge */}
        <motion.div
          initial={{ scale: 0.5, opacity: 0, rotate: -10 }}
          animate={{ scale: 1, opacity: 1, rotate: 0 }}
          transition={{ duration: 0.8, type: 'spring' }}
          className="relative mb-6"
        >
          <div className="w-28 h-28 rounded-full bg-gradient-to-tr from-emerald-400 via-teal-300 to-sky-400 p-1 shadow-2xl shadow-emerald-950/60 flex items-center justify-center">
            <div className="w-full h-full rounded-full bg-emerald-950 flex flex-col items-center justify-center p-2 border border-emerald-400/30">
              <div className="flex items-center gap-1 text-emerald-300">
                <ShieldCheck className="w-8 h-8 text-emerald-400" />
                <HeartHandshake className="w-8 h-8 text-sky-300" />
              </div>
              <span className="text-[10px] font-bold text-amber-300 mt-1 tracking-widest uppercase">SMP-OP</span>
            </div>
          </div>
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
            className="absolute -inset-2 rounded-full border border-dashed border-emerald-300/30 pointer-events-none"
          />
        </motion.div>

        <motion.h1
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="text-2xl sm:text-3xl font-extrabold text-white tracking-wide font-['Noto_Serif_Bengali'] mb-2"
        >
          ছাদেক মোহাম্মদ পাড়া ঐক্য পরিষদ
        </motion.h1>

        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-500/20 border border-emerald-400/30 backdrop-blur-md mb-8"
        >
          <Sparkles className="w-4 h-4 text-amber-300" />
          <p className="text-sm font-medium text-emerald-200">ঐক্যে শক্তি, মানবতায় সেবা</p>
        </motion.div>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.7 }}
          className="text-xs text-emerald-100/80 max-w-xs"
        >
          সামাজিক উন্নয়ন, মানবসেবা ও ঐক্যবদ্ধ ছাদেক মোহাম্মদ পাড়া গড়ার ডিজিটাল প্ল্যাটফর্ম
        </motion.p>
      </div>

      <div className="w-full max-w-xs pb-4">
        <motion.button
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.9 }}
          whileTap={{ scale: 0.98 }}
          onClick={onFinish}
          className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-emerald-400 to-sky-400 text-slate-950 font-bold text-base shadow-lg shadow-emerald-500/20 hover:brightness-110 transition flex items-center justify-center gap-2"
        >
          <span>অ্যাপে প্রবেশ করুন</span>
          <span className="text-xl">➔</span>
        </motion.button>
      </div>
    </motion.div>
  );
};
