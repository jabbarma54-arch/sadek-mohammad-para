import React, { useState } from 'react';
import { MessageSquare, Phone, Mail, MapPin, Send, CheckCircle2, Facebook, MessageCircle, ExternalLink } from 'lucide-react';
import { Opinion } from '../types';

interface FeedbackAndContactProps {
  opinions: Opinion[];
  onAddOpinion: (newOpinion: Opinion) => void;
}

export const FeedbackAndContact: React.FC<FeedbackAndContactProps> = ({ opinions, onAddOpinion }) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !message) return;

    const newOp: Opinion = {
      id: `op${Date.now()}`,
      name,
      phone,
      message,
      date: new Date().toISOString().split('T')[0]
    };

    onAddOpinion(newOp);
    setSubmitted(true);
    setName('');
    setPhone('');
    setMessage('');
    setTimeout(() => setSubmitted(false), 4000);
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Title */}
      <div className="text-center space-y-2 max-w-xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-100 dark:bg-blue-950 text-blue-800 dark:text-blue-300 text-xs font-bold">
          <Phone className="w-4 h-4" />
          <span>যোগাযোগ ও মতামত পোর্টাল</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white font-['Noto_Serif_Bengali']">
          আমাদের সাথে যোগাযোগ করুন
        </h2>
        <p className="text-slate-600 dark:text-slate-300 text-sm">
          আপনার মূল্যবান পরামর্শ, মতামত বা যেকোনো সহায়তার জন্য সরাসরি যোগাযোগ করুন
        </p>
      </div>

      {/* Quick Direct Channels Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
        <a
          href="tel:+8801711223344"
          className="bg-white dark:bg-slate-900 p-4 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm hover:shadow-md transition flex items-center gap-3"
        >
          <div className="p-3 rounded-2xl bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400">
            <Phone className="w-6 h-6" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-slate-500">জরুরি ফোন</h4>
            <p className="text-sm font-bold text-slate-900 dark:text-white">+880 1711-223344</p>
          </div>
        </a>

        <a
          href="https://wa.me/8801711223344"
          target="_blank"
          rel="noreferrer"
          className="bg-white dark:bg-slate-900 p-4 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm hover:shadow-md transition flex items-center gap-3"
        >
          <div className="p-3 rounded-2xl bg-teal-100 dark:bg-teal-950 text-teal-600 dark:text-teal-400">
            <MessageCircle className="w-6 h-6" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-slate-500">WhatsApp হেল্পলাইন</h4>
            <p className="text-sm font-bold text-slate-900 dark:text-white">সরাসরি চ্যাট</p>
          </div>
        </a>

        <a
          href="https://facebook.com"
          target="_blank"
          rel="noreferrer"
          className="bg-white dark:bg-slate-900 p-4 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm hover:shadow-md transition flex items-center gap-3"
        >
          <div className="p-3 rounded-2xl bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-400">
            <Facebook className="w-6 h-6" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-slate-500">ফেসবুক পেজ</h4>
            <p className="text-sm font-bold text-slate-900 dark:text-white">অফিশিয়াল পেজ</p>
          </div>
        </a>

        <a
          href="mailto:contact@sadekpara-unity.org"
          className="bg-white dark:bg-slate-900 p-4 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm hover:shadow-md transition flex items-center gap-3"
        >
          <div className="p-3 rounded-2xl bg-amber-100 dark:bg-amber-950 text-amber-600 dark:text-amber-400">
            <Mail className="w-6 h-6" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-slate-500">ইমেইল</h4>
            <p className="text-xs font-bold text-slate-900 dark:text-white truncate">sadekpara@gmail.com</p>
          </div>
        </a>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Feedback / Opinion Form */}
        <form onSubmit={handleSubmit} className="md:col-span-7 bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
          <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2 font-['Noto_Serif_Bengali']">
            <MessageSquare className="w-5 h-5 text-emerald-600" />
            <span>আপনার মতামত ও পরামর্শ পাঠান</span>
          </h3>

          {submitted && (
            <div className="p-3 bg-emerald-100 text-emerald-800 rounded-xl text-xs font-bold flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>ধন্যবাদ! আপনার বার্তা সফলভাবে পাঠানো হয়েছে।</span>
            </div>
          )}

          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
              আপনার নাম *
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="নাম লিখুন"
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 text-sm text-slate-900 dark:text-white outline-none"
            />
          </div>

          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
              মোবাইল নম্বর
            </label>
            <input
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="017XXXXXXXX"
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 text-sm text-slate-900 dark:text-white outline-none"
            />
          </div>

          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
              পরামর্শ বা বার্তার বিবরণ *
            </label>
            <textarea
              required
              rows={4}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="এলাকার উন্নয়ন বা অ্যাপ সম্পর্কে যেকোনো গঠনমূলক বার্তা লিখুন..."
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 text-sm text-slate-900 dark:text-white outline-none resize-none"
            ></textarea>
          </div>

          <button
            type="submit"
            className="w-full py-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-sm shadow transition flex items-center justify-center gap-2"
          >
            <Send className="w-4 h-4" />
            <span>মতামত জমা দিন</span>
          </button>
        </form>

        {/* Location & Map Box */}
        <div className="md:col-span-5 bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
          <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2 font-['Noto_Serif_Bengali']">
            <MapPin className="w-5 h-5 text-emerald-600" />
            <span>আমাদের অবস্থান ও ঠিকানা</span>
          </h3>

          <div className="space-y-2 text-xs text-slate-600 dark:text-slate-300">
            <p><strong className="text-slate-900 dark:text-white">কেন্দ্রীয় কার্যালয়:</strong> ছাদেক মোহাম্মদ পাড়া জামে মসজিদ সংলগ্ন, ওয়ার্ড নং ৪</p>
            <p><strong className="text-slate-900 dark:text-white">উপজেলা / থানা:</strong> সদর</p>
            <p><strong className="text-slate-900 dark:text-white">সময়সূচী:</strong> প্রতিদিন বিকাল ৪:০০ - রাত ৯:০০</p>
          </div>

          {/* Map Simulation */}
          <div className="relative h-48 rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-emerald-950 flex flex-col items-center justify-center p-4 text-center text-white">
            <MapPin className="w-8 h-8 text-amber-400 animate-bounce mb-2" />
            <h4 className="text-sm font-bold font-['Noto_Serif_Bengali']">ছাদেক মোহাম্মদ পাড়া</h4>
            <p className="text-[11px] text-emerald-300">ঐক্য পরিষদ কেন্দ্রীয় অফিস লোকেশন</p>
            <span className="mt-2 text-[10px] bg-white/20 px-3 py-1 rounded-full backdrop-blur-md">
              Google Maps Pin Verified
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
