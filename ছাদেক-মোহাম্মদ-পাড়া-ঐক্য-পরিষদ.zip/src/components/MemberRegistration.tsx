import React, { useState } from 'react';
import { UserPlus, CheckCircle2, IdCard, Upload, Sparkles, AlertCircle } from 'lucide-react';
import { Member } from '../types';
import { DigitalIdCard } from './DigitalIdCard';

interface MemberRegistrationProps {
  onRegisterMember: (newMember: Member) => void;
  existingMembers: Member[];
}

export const MemberRegistration: React.FC<MemberRegistrationProps> = ({
  onRegisterMember,
  existingMembers
}) => {
  const [nameBn, setNameBn] = useState('');
  const [nameEn, setNameEn] = useState('');
  const [phone, setPhone] = useState('');
  const [fatherName, setFatherName] = useState('');
  const [address, setAddress] = useState('ছাদেক মোহাম্মদ পাড়া');
  const [nid, setNid] = useState('');
  const [bloodGroup, setBloodGroup] = useState('O+');
  const [occupation, setOccupation] = useState('ব্যবসায়ী');
  const [photoUrl, setPhotoUrl] = useState('');
  const [registeredMember, setRegisteredMember] = useState<Member | null>(null);
  const [selectedExistingMember, setSelectedExistingMember] = useState<Member | null>(null);

  const bloodGroups = ['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nameBn || !phone) return;

    const newId = `m${Date.now()}`;
    const memberNo = `SMP-2026-${String(existingMembers.length + 1).padStart(3, '0')}`;
    
    const newMem: Member = {
      id: newId,
      memberNo,
      nameBn,
      nameEn: nameEn || nameBn,
      phone,
      fatherName,
      address,
      nid,
      bloodGroup,
      occupation,
      photoUrl: photoUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80',
      joinDate: new Date().toISOString().split('T')[0],
      status: 'approved',
      role: 'member'
    };

    onRegisterMember(newMem);
    setRegisteredMember(newMem);
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Title */}
      <div className="text-center space-y-2 max-w-xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 text-xs font-bold">
          <UserPlus className="w-4 h-4" />
          <span>অনলাইন সদস্য পোর্টালে স্বাগতম</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white font-['Noto_Serif_Bengali']">
          ছাদেক মোহাম্মদ পাড়া সদস্য নিবন্ধন
        </h2>
        <p className="text-slate-600 dark:text-slate-300 text-sm">
          নিবন্ধন সম্পন্ন করুন এবং সাথে সাথেই আপনার ডিজিটাল সদস্য পরিচয়পত্র (ID Card) বুঝে নিন।
        </p>
      </div>

      {/* Main Tabs: Register vs View Existing ID Card */}
      <div className="max-w-xl mx-auto bg-slate-200 dark:bg-slate-800 p-1 rounded-2xl flex items-center">
        <button
          onClick={() => { setRegisteredMember(null); setSelectedExistingMember(null); }}
          className={`flex-1 py-2.5 px-4 rounded-xl text-xs font-bold transition ${
            !selectedExistingMember ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow' : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          নতুন সদস্য ফরম পূরণ
        </button>
        <button
          onClick={() => setSelectedExistingMember(existingMembers[0] || null)}
          className={`flex-1 py-2.5 px-4 rounded-xl text-xs font-bold transition ${
            selectedExistingMember ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow' : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          বিদ্যমান সদস্য আইডি কার্ড খুঁজুন ({existingMembers.length})
        </button>
      </div>

      {/* Show Existing Member Selector */}
      {selectedExistingMember ? (
        <div className="space-y-6">
          <div className="max-w-md mx-auto bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
              সদস্য বাছাই করুন:
            </label>
            <select
              value={selectedExistingMember.id}
              onChange={(e) => {
                const found = existingMembers.find(m => m.id === e.target.value);
                if (found) setSelectedExistingMember(found);
              }}
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl p-2.5 text-sm text-slate-900 dark:text-white outline-none"
            >
              {existingMembers.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.nameBn} ({m.memberNo}) - {m.phone}
                </option>
              ))}
            </select>
          </div>

          <DigitalIdCard member={selectedExistingMember} />
        </div>
      ) : registeredMember ? (
        /* Newly Registered Success Card View */
        <div className="space-y-6 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-2xl bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 text-sm font-bold border border-emerald-300">
            <CheckCircle2 className="w-5 h-5 text-emerald-600" />
            <span>অভিনন্দন! আপনার সদস্য নিবন্ধন সফলভাবে সম্পন্ন হয়েছে।</span>
          </div>

          <DigitalIdCard member={registeredMember} />

          <button
            onClick={() => setRegisteredMember(null)}
            className="px-6 py-2.5 rounded-2xl bg-slate-800 text-white font-bold text-xs hover:bg-slate-700 transition"
          >
            + অন্য নতুন সদস্য নিবন্ধন করুন
          </button>
        </div>
      ) : (
        /* Registration Form */
        <form onSubmit={handleSubmit} className="max-w-2xl mx-auto bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Name Bn */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                সদস্যের নাম (বাংলায়) *
              </label>
              <input
                type="text"
                required
                value={nameBn}
                onChange={(e) => setNameBn(e.target.value)}
                placeholder="যেমন: মোঃ জহিরুল ইসলাম"
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
              />
            </div>

            {/* Name En */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                Name in English
              </label>
              <input
                type="text"
                value={nameEn}
                onChange={(e) => setNameEn(e.target.value)}
                placeholder="e.g. Md. Zahirul Islam"
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
              />
            </div>

            {/* Phone */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                মোবাইল নম্বর *
              </label>
              <input
                type="tel"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="017XXXXXXXX"
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
              />
            </div>

            {/* Father Name */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                পিতার নাম
              </label>
              <input
                type="text"
                value={fatherName}
                onChange={(e) => setFatherName(e.target.value)}
                placeholder="পিতার নাম লিখুন"
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
              />
            </div>

            {/* Blood Group */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                রক্তের গ্রুপ
              </label>
              <select
                value={bloodGroup}
                onChange={(e) => setBloodGroup(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
              >
                {bloodGroups.map((bg) => (
                  <option key={bg} value={bg}>{bg}</option>
                ))}
              </select>
            </div>

            {/* Occupation */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                পেশা
              </label>
              <input
                type="text"
                value={occupation}
                onChange={(e) => setOccupation(e.target.value)}
                placeholder="যেমন: ব্যবসায়ী / শিক্ষক / শিক্ষার্থী"
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
              />
            </div>

            {/* Address */}
            <div className="space-y-1 sm:col-span-2">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                ঠিকানা (পাড়া ও বাড়ীর নাম)
              </label>
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="উত্তর পাড়া, ছাদেক মোহাম্মদ পাড়া"
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
              />
            </div>

            {/* NID */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                জাতীয় পরিচয়পত্র / জন্ম নিবন্ধন (ঐচ্ছিক)
              </label>
              <input
                type="text"
                value={nid}
                onChange={(e) => setNid(e.target.value)}
                placeholder="NID নম্বর"
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
              />
            </div>

            {/* Photo Link / Preset */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                ছবি লিংক বা প্রিসেট
              </label>
              <input
                type="url"
                value={photoUrl}
                onChange={(e) => setPhotoUrl(e.target.value)}
                placeholder="https://... (ফাঁকা রাখলে ডেমো ছবি যুক্ত হবে)"
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 text-sm text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
              />
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 text-xs text-emerald-800 dark:text-emerald-300 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>আবেদন জমা দিলেই আপনার ডিজিটাল কিউআর কোড যুক্ত সদস্য পরিচয়পত্র তাৎক্ষণিক জেনারেট হয়ে যাবে।</span>
          </div>

          <button
            type="submit"
            className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-emerald-600 to-sky-600 text-white font-extrabold text-sm shadow-md hover:brightness-110 transition flex items-center justify-center gap-2"
          >
            <UserPlus className="w-4 h-4" />
            <span>সদস্য নিবন্ধন সম্পন্ন করুন</span>
          </button>
        </form>
      )}
    </div>
  );
};
