import React, { useState } from 'react';
import { Bell, Megaphone, Calendar, FileText, Download, Filter, Search, ShieldAlert, X } from 'lucide-react';
import { Notice } from '../types';

interface NoticeSectionProps {
  notices: Notice[];
  selectedNoticeDetail: Notice | null;
  onSelectNoticeDetail: (notice: Notice | null) => void;
}

export const NoticeSection: React.FC<NoticeSectionProps> = ({
  notices,
  selectedNoticeDetail,
  onSelectNoticeDetail
}) => {
  const [filterCategory, setFilterCategory] = useState<string>('সবগুলো');
  const [search, setSearch] = useState('');

  const categories = ['সবগুলো', 'জরুরি', 'সভা', 'ইভেন্ট', 'সাধারণ'];

  const filteredNotices = notices.filter((n) => {
    const matchesCat = filterCategory === 'সবগুলো' || n.category === filterCategory;
    const matchesSearch = n.title.toLowerCase().includes(search.toLowerCase()) || n.content.toLowerCase().includes(search.toLowerCase());
    return matchesCat && matchesSearch;
  });

  return (
    <div className="space-y-6 pb-12">
      {/* Title */}
      <div className="text-center space-y-2 max-w-xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-orange-100 dark:bg-orange-950 text-orange-800 dark:text-orange-300 text-xs font-bold">
          <Bell className="w-4 h-4" />
          <span>অফিশিয়াল নোটিশ বোর্ড</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white font-['Noto_Serif_Bengali']">
          জরুরি তথ্য ও নোটিশসমূহ
        </h2>
        <p className="text-slate-600 dark:text-slate-300 text-sm">
          ছাদেক মোহাম্মদ পাড়া ঐক্য পরিষদের সাধারণ ও জরুরি সভার সিদ্ধান্ত ও নোটিশ
        </p>
      </div>

      {/* Search & Category Filter */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 rounded-3xl border border-slate-200/80 dark:border-slate-800 shadow-sm">
        {/* Categories */}
        <div className="flex flex-wrap gap-1.5 w-full sm:w-auto">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setFilterCategory(cat)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                filterCategory === cat
                  ? 'bg-emerald-600 text-white shadow'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Search Input */}
        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="নোটিশ খুঁজুন..."
            className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl pl-9 pr-3 py-1.5 text-xs text-slate-900 dark:text-white outline-none"
          />
        </div>
      </div>

      {/* Notices List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredNotices.map((notice) => (
          <div
            key={notice.id}
            onClick={() => onSelectNoticeDetail(notice)}
            className={`bg-white dark:bg-slate-900 rounded-3xl p-5 border transition cursor-pointer space-y-3 hover:shadow-md relative overflow-hidden ${
              notice.isUrgent
                ? 'border-amber-400 dark:border-amber-500 shadow-amber-500/10'
                : 'border-slate-200/80 dark:border-slate-800'
            }`}
          >
            {notice.isUrgent && (
              <span className="absolute top-0 right-0 bg-amber-500 text-slate-950 font-extrabold text-[10px] px-3 py-1 rounded-bl-2xl uppercase flex items-center gap-1">
                <Megaphone className="w-3 h-3" />
                <span>জরুরি</span>
              </span>
            )}

            <div className="flex items-center gap-2 text-xs">
              <span className="px-2.5 py-0.5 rounded-lg bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-extrabold">
                {notice.category}
              </span>
              <span className="text-slate-400 text-[11px]">🗓️ {notice.date}</span>
            </div>

            <h3 className="text-base font-bold text-slate-900 dark:text-white font-['Noto_Serif_Bengali']">
              {notice.title}
            </h3>

            <p className="text-xs text-slate-600 dark:text-slate-300 line-clamp-2 leading-relaxed">
              {notice.content}
            </p>

            <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[11px] text-slate-500">
              <span>প্রকাশক: {notice.publishedBy}</span>
              <span className="text-emerald-600 dark:text-emerald-400 font-bold hover:underline">
                সম্পূর্ণ দেখুন →
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Expanded Modal View for Notice */}
      {selectedNoticeDetail && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm">
          <div className="bg-white dark:bg-slate-900 max-w-lg w-full rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4 relative max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => onSelectNoticeDetail(null)}
              className="absolute top-4 right-4 p-2 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-500 hover:text-slate-900 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2 text-xs">
              <span className="px-3 py-1 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-bold">
                {selectedNoticeDetail.category}
              </span>
              <span className="text-slate-400">তারিখ: {selectedNoticeDetail.date}</span>
            </div>

            <h3 className="text-xl font-bold text-slate-900 dark:text-white font-['Noto_Serif_Bengali']">
              {selectedNoticeDetail.title}
            </h3>

            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 text-sm text-slate-700 dark:text-slate-200 leading-relaxed space-y-2">
              <p>{selectedNoticeDetail.content}</p>
            </div>

            <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500">
              <span>প্রকাশনায়: {selectedNoticeDetail.publishedBy}</span>
              <button
                onClick={() => window.print()}
                className="px-4 py-2 rounded-xl bg-emerald-600 text-white font-bold flex items-center gap-1.5 shadow"
              >
                <Download className="w-4 h-4" />
                <span>নোটিশ প্রিন্ট / ডাউনলোড</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
