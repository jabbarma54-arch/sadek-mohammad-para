import React from 'react';
import { 
  Users, 
  UserPlus, 
  IdCard, 
  CreditCard, 
  Bell, 
  Heart, 
  Calendar, 
  PhoneCall, 
  Droplets, 
  ArrowRight, 
  Sparkles, 
  CheckCircle2, 
  ExternalLink,
  ChevronRight,
  Gift,
  ShieldCheck,
  Megaphone,
  BookOpen
} from 'lucide-react';
import { CommitteeMember, Notice, Activity, EventItem, Member } from '../types';
import { TabType } from './Navigation';

interface HomeScreenProps {
  onNavigate: (tab: TabType) => void;
  committee: CommitteeMember[];
  notices: Notice[];
  activities: Activity[];
  events: EventItem[];
  members: Member[];
  onOpenNoticeDetail: (notice: Notice) => void;
  onOpenActivityDetail: (activity: Activity) => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  onNavigate,
  committee,
  notices,
  activities,
  events,
  members,
  onOpenNoticeDetail,
  onOpenActivityDetail
}) => {
  const president = committee.find(c => c.designation === 'সভাপতি') || committee[0];
  const secretary = committee.find(c => c.designation === 'সাধারণ সম্পাদক') || committee[2];
  const urgentNotice = notices.find(n => n.isUrgent) || notices[0];

  const quickMenus = [
    { id: 'about' as TabType, label: 'আমাদের সম্পর্কে', bg: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800', icon: <BookOpen className="w-6 h-6" /> },
    { id: 'committee' as TabType, label: 'কমিটি সদস্য', bg: 'bg-sky-50 text-sky-700 dark:bg-sky-950/60 dark:text-sky-300 border-sky-200 dark:border-sky-800', icon: <Users className="w-6 h-6" /> },
    { id: 'register' as TabType, label: 'সদস্য নিবন্ধন', bg: 'bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300 border-amber-200 dark:border-amber-800', icon: <UserPlus className="w-6 h-6" /> },
    { id: 'idcard' as TabType, label: 'ডিজিটাল কার্ড', bg: 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300 border-indigo-200 dark:border-indigo-800', icon: <IdCard className="w-6 h-6" /> },
    { id: 'donation' as TabType, label: 'অনুদানের ফান্ড', bg: 'bg-teal-50 text-teal-700 dark:bg-teal-950/60 dark:text-teal-300 border-teal-200 dark:border-teal-800', icon: <CreditCard className="w-6 h-6" /> },
    { id: 'humanitarian' as TabType, label: 'মানবিক সেবা', bg: 'bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300 border-rose-200 dark:border-rose-800', icon: <Heart className="w-6 h-6" /> },
    { id: 'notice' as TabType, label: 'নোটিশ বোর্ড', bg: 'bg-orange-50 text-orange-700 dark:bg-orange-950/60 dark:text-orange-300 border-orange-200 dark:border-orange-800', icon: <Bell className="w-6 h-6" /> },
    { id: 'contact' as TabType, label: 'জরুরি যোগাযোগ', bg: 'bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300 border-blue-200 dark:border-blue-800', icon: <PhoneCall className="w-6 h-6" /> }
  ];

  return (
    <div className="space-y-6 pb-12">
      {/* Urgent Notice Ticker */}
      {urgentNotice && (
        <div className="bg-amber-500 text-slate-950 px-4 py-2 shadow-sm flex items-center gap-3 overflow-hidden rounded-2xl border border-amber-400">
          <div className="flex items-center gap-1.5 font-bold text-xs shrink-0 bg-amber-900 text-amber-100 px-2.5 py-1 rounded-lg uppercase tracking-wide">
            <Megaphone className="w-3.5 h-3.5 animate-bounce" />
            <span>জরুরি ঘোষণা:</span>
          </div>
          <div className="flex-1 overflow-hidden truncate">
            <p 
              onClick={() => onOpenNoticeDetail(urgentNotice)} 
              className="text-xs sm:text-sm font-semibold truncate hover:underline cursor-pointer text-slate-950"
            >
              {urgentNotice.title} - {urgentNotice.content}
            </p>
          </div>
          <button 
            onClick={() => onNavigate('notice')}
            className="text-xs font-bold text-slate-950 hover:underline shrink-0 flex items-center gap-0.5"
          >
            <span>সব দেখুন</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Hero Welcome Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-800 via-emerald-700 to-sky-800 text-white p-6 sm:p-8 shadow-xl">
        <div className="absolute -right-12 -bottom-12 w-64 h-64 rounded-full bg-emerald-500/20 blur-3xl pointer-events-none"></div>
        <div className="absolute top-0 right-0 w-48 h-48 rounded-full bg-sky-400/20 blur-2xl pointer-events-none"></div>

        <div className="relative z-10 grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
          <div className="md:col-span-8 space-y-4">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-emerald-200 text-xs font-semibold">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>ছাদেক মোহাম্মদ পাড়া ঐক্য পরিষদ অফিশিয়াল অ্যাপ</span>
            </div>

            <h2 className="text-2xl sm:text-4xl font-extrabold tracking-tight font-['Noto_Serif_Bengali'] leading-snug">
              ঐক্যের বন্ধনে সমৃদ্ধ পাড়া, <br className="hidden sm:inline" />
              <span className="text-amber-300">মানবসেবায় চির অঙ্গীকারবদ্ধ।</span>
            </h2>

            <p className="text-emerald-100 text-sm leading-relaxed max-w-xl">
              ছাদেক মোহাম্মদ পাড়া ঐক্য পরিষদ আমাদের এলাকার সকল বাসিন্দাদের পারস্পরিক সহায়তা, সামাজিক উন্নয়ন, ডিজিটাল আইডি নেটওয়ার্ক ও দুঃস্থদের সেবায় কাজ করে যাচ্ছে।
            </p>

            <div className="pt-2 flex flex-wrap gap-3">
              <button
                onClick={() => onNavigate('register')}
                className="px-5 py-2.5 rounded-xl bg-amber-400 text-slate-950 font-bold text-sm hover:bg-amber-300 transition shadow-lg flex items-center gap-2"
              >
                <UserPlus className="w-4 h-4" />
                <span>সদস্য নিবন্ধন করুন</span>
              </button>

              <button
                onClick={() => onNavigate('donation')}
                className="px-5 py-2.5 rounded-xl bg-white/15 hover:bg-white/25 text-white font-semibold text-sm backdrop-blur-md border border-white/20 transition flex items-center gap-2"
              >
                <Gift className="w-4 h-4 text-emerald-300" />
                <span>অনুদানে শরিক হন</span>
              </button>
            </div>
          </div>

          {/* Quick Counter Box */}
          <div className="md:col-span-4 bg-emerald-950/60 backdrop-blur-md rounded-2xl p-4 border border-emerald-500/30 space-y-3">
            <h3 className="text-xs font-bold text-emerald-300 uppercase tracking-wider flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>এক নজরে আমাদের তথ্য</span>
            </h3>

            <div className="grid grid-cols-2 gap-2 text-center">
              <div className="bg-emerald-900/50 p-2.5 rounded-xl border border-emerald-800">
                <span className="text-xl sm:text-2xl font-black text-amber-300">{members.length}</span>
                <p className="text-[11px] text-emerald-200">নিবন্ধিত সদস্য</p>
              </div>

              <div className="bg-emerald-900/50 p-2.5 rounded-xl border border-emerald-800">
                <span className="text-xl sm:text-2xl font-black text-sky-300">{activities.length}</span>
                <p className="text-[11px] text-emerald-200">চালু প্রকল্প</p>
              </div>

              <div className="bg-emerald-900/50 p-2.5 rounded-xl border border-emerald-800">
                <span className="text-xl sm:text-2xl font-black text-rose-300">৪৫+</span>
                <p className="text-[11px] text-emerald-200">রক্তদান সেবা</p>
              </div>

              <div className="bg-emerald-900/50 p-2.5 rounded-xl border border-emerald-800">
                <span className="text-xl sm:text-2xl font-black text-emerald-300">১৫০+</span>
                <p className="text-[11px] text-emerald-200">উপকারভোগী</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Menu Grid (দ্রুত সেবা) */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-base sm:text-lg font-bold text-slate-800 dark:text-white flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-600"></span>
            <span>দ্রুত সেবা (Quick Menu)</span>
          </h3>
          <span className="text-xs text-slate-500 dark:text-slate-400">সহজ ন্যাভিগেশন</span>
        </div>

        <div className="grid grid-cols-4 sm:grid-cols-4 md:grid-cols-8 gap-2.5">
          {quickMenus.map((menu) => (
            <button
              key={menu.id}
              onClick={() => onNavigate(menu.id)}
              className={`flex flex-col items-center justify-center p-3 rounded-2xl border transition-all duration-200 hover:-translate-y-1 hover:shadow-md ${menu.bg}`}
            >
              <div className="p-2 rounded-xl mb-1.5">{menu.icon}</div>
              <span className="text-[11px] font-bold text-center leading-tight">{menu.label}</span>
            </button>
          ))}
        </div>
      </section>

      {/* President's & General Secretary Message (সভাপতি ও সাধারণ সম্পাদকের বার্তা) */}
      {president && (
        <section className="bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-sm border border-slate-200/80 dark:border-slate-800 grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
          <div className="md:col-span-4 flex flex-col items-center text-center">
            <div className="relative mb-3">
              <img
                src={president.photoUrl}
                alt={president.name}
                className="w-28 h-28 rounded-2xl object-cover shadow-md border-2 border-emerald-500"
              />
              <span className="absolute -bottom-2 px-3 py-0.5 rounded-full bg-emerald-700 text-white text-[10px] font-bold uppercase tracking-wider">
                {president.designation}
              </span>
            </div>
            <h4 className="text-base font-bold text-slate-900 dark:text-white font-['Noto_Serif_Bengali']">{president.name}</h4>
            <p className="text-xs text-emerald-600 dark:text-emerald-400 font-medium">ছাদেক মোহাম্মদ পাড়া ঐক্য পরিষদ</p>
          </div>

          <div className="md:col-span-8 space-y-3 border-t md:border-t-0 md:border-l border-slate-100 dark:border-slate-800 pt-4 md:pt-0 md:pl-6">
            <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 px-3 py-1 rounded-full">
              <Sparkles className="w-3.5 h-3.5" />
              <span>সভাপতি'র শুভেচ্ছা বার্তা</span>
            </div>

            <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed italic">
              "{president.speech || 'ছাদেক মোহাম্মদ পাড়া ঐক্য পরিষদ একটি অরাজনৈতিক, সামাজিক ও মানবসেবামূলক সংগঠন। সামাজিক ঐক্য, শিক্ষার প্রসার ও যুবসমাজকে সৎ পথে রাখার লক্ষ্যেই আমাদের পথচলা।'}"
            </p>

            <div className="pt-2 flex items-center justify-between">
              <a 
                href={`tel:${president.phone}`}
                className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-700 dark:text-emerald-400 hover:underline"
              >
                <PhoneCall className="w-3.5 h-3.5" />
                <span>যোগাযোগ: {president.phone}</span>
              </a>

              <button
                onClick={() => onNavigate('committee')}
                className="text-xs font-bold text-sky-600 dark:text-sky-400 hover:underline flex items-center gap-1"
              >
                <span>পূর্ণাঙ্গ কমিটি দেখুন</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </section>
      )}

      {/* Ongoing Activities & Humanitarian Service Cards */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Heart className="w-5 h-5 text-rose-500 fill-rose-500" />
              <span>চলমান কার্যক্রম ও মানবিক সেবা</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">এলাকাবাসীর কল্যাণে আমাদের সাম্প্রতিক উন্নয়নমূলক উদ্যোগ</p>
          </div>

          <button
            onClick={() => onNavigate('humanitarian')}
            className="text-xs font-bold text-emerald-700 dark:text-emerald-400 hover:underline flex items-center gap-1"
          >
            <span>সকল কার্যক্রম</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {activities.slice(0, 2).map((act) => (
            <div 
              key={act.id}
              className="bg-white dark:bg-slate-900 rounded-2xl overflow-hidden border border-slate-200/80 dark:border-slate-800 shadow-sm hover:shadow-md transition group"
            >
              <div className="relative h-44 overflow-hidden">
                <img 
                  src={act.imageUrl} 
                  alt={act.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition duration-300" 
                />
                <span className="absolute top-3 left-3 bg-emerald-800/90 text-white text-[11px] font-bold px-2.5 py-1 rounded-lg backdrop-blur-md">
                  {act.category}
                </span>
                <span className={`absolute top-3 right-3 text-[11px] font-bold px-2.5 py-1 rounded-lg backdrop-blur-md ${
                  act.status === 'active' ? 'bg-amber-500 text-slate-950' : 'bg-slate-900/80 text-white'
                }`}>
                  {act.status === 'active' ? 'চলমান' : 'সম্পন্ন'}
                </span>
              </div>

              <div className="p-4 space-y-2">
                <h4 className="text-base font-bold text-slate-900 dark:text-white group-hover:text-emerald-600 transition">
                  {act.title}
                </h4>
                <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-2">
                  {act.description}
                </p>

                {act.targetAmount && (
                  <div className="space-y-1 pt-2">
                    <div className="flex justify-between text-xs font-semibold text-slate-700 dark:text-slate-300">
                      <span>সংগৃহীত: ৳{act.raisedAmount?.toLocaleString('bn-BD')}</span>
                      <span>লক্ষ্য: ৳{act.targetAmount?.toLocaleString('bn-BD')}</span>
                    </div>
                    <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                      <div 
                        className="bg-emerald-500 h-full rounded-full" 
                        style={{ width: `${Math.min(100, Math.round(((act.raisedAmount || 0) / act.targetAmount) * 100))}%` }}
                      ></div>
                    </div>
                  </div>
                )}

                <div className="pt-2 flex items-center justify-between">
                  <span className="text-[11px] text-slate-500">উপকারভোগী: {act.beneficiariesCount} জন</span>
                  <button
                    onClick={() => onOpenActivityDetail(act)}
                    className="text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1"
                  >
                    <span>বিস্তারিত পড়ুন</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Emergency Blood Donor Call Box */}
      <section className="bg-gradient-to-r from-rose-900 via-rose-800 to-rose-950 text-white rounded-3xl p-6 shadow-md border border-rose-700/50 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-white/10 flex items-center justify-center shrink-0 border border-white/20">
            <Droplets className="w-8 h-8 text-rose-300 animate-pulse" />
          </div>
          <div>
            <h4 className="text-lg font-bold text-white font-['Noto_Serif_Bengali']">জরুরি রক্তের প্রয়োজন?</h4>
            <p className="text-xs text-rose-200">আমাদের পাড়ার স্বেচ্ছাসেবী রক্তদাতাদের নেটওয়ার্ক থেকে সাহায্য নিন</p>
          </div>
        </div>

        <button
          onClick={() => onNavigate('humanitarian')}
          className="w-full md:w-auto px-6 py-3 rounded-2xl bg-white text-rose-900 font-extrabold text-sm shadow hover:bg-rose-50 transition flex items-center justify-center gap-2 shrink-0"
        >
          <Droplets className="w-4 h-4 text-rose-600" />
          <span>রক্তদাতার তালিকা খুঁজুন</span>
        </button>
      </section>

      {/* Latest Notices & Upcoming Events Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Latest Notices */}
        <section className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Bell className="w-4 h-4 text-emerald-600" />
              <span>সর্বশেষ নোটিশ</span>
            </h3>
            <button
              onClick={() => onNavigate('notice')}
              className="text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:underline"
            >
              সবগুলো ನೋটিশ
            </button>
          </div>

          <div className="space-y-3">
            {notices.slice(0, 3).map((notice) => (
              <div
                key={notice.id}
                onClick={() => onOpenNoticeDetail(notice)}
                className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 hover:border-emerald-300 dark:hover:border-emerald-700 transition cursor-pointer space-y-1"
              >
                <div className="flex items-center justify-between text-[11px]">
                  <span className="px-2 py-0.5 rounded-md bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 font-bold">
                    {notice.category}
                  </span>
                  <span className="text-slate-400">{notice.date}</span>
                </div>
                <h4 className="text-sm font-bold text-slate-800 dark:text-slate-200">
                  {notice.title}
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-1">
                  {notice.content}
                </p>
              </div>
            ))}
          </div>
        </section>

        {/* Upcoming Events */}
        <section className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Calendar className="w-4 h-4 text-sky-600" />
              <span>আগামী ইভেন্ট ও অনুষ্ঠান</span>
            </h3>
            <button
              onClick={() => onNavigate('events')}
              className="text-xs font-bold text-sky-600 dark:text-sky-400 hover:underline"
            >
              ক্যালেন্ডার দেখুন
            </button>
          </div>

          <div className="space-y-3">
            {events.slice(0, 3).map((evt) => (
              <div
                key={evt.id}
                className="p-3.5 rounded-2xl bg-sky-50/50 dark:bg-slate-800/60 border border-sky-100 dark:border-slate-800 flex items-start gap-3"
              >
                <div className="bg-sky-600 text-white rounded-xl p-2.5 text-center min-w-[54px] shrink-0">
                  <span className="text-[10px] block font-bold uppercase tracking-wider">{evt.category}</span>
                  <span className="text-xs font-extrabold">{evt.date.slice(-5)}</span>
                </div>

                <div className="space-y-1">
                  <h4 className="text-sm font-bold text-slate-800 dark:text-slate-200">{evt.title}</h4>
                  <p className="text-xs text-slate-600 dark:text-slate-400">📍 {evt.location}</p>
                  <p className="text-[11px] text-sky-700 dark:text-sky-300 font-medium">🕒 {evt.time}</p>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};
