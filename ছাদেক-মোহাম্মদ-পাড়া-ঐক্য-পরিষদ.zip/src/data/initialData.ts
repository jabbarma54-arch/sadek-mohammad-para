import { Member, CommitteeMember, Notice, Activity, EventItem, Donation, GalleryItem } from '../types';

export const INITIAL_COMMITTEE: CommitteeMember[] = [
  {
    id: 'c1',
    name: 'হাজী মোঃ আব্দুর রশিদ',
    designation: 'সভাপতি',
    phone: '+8801711223344',
    photoUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop&q=80',
    priority: 1,
    speech: 'ঐক্য ও মানবসেবাই আমাদের পরম ধর্ম। ছাদেক মোহাম্মদ পাড়াকে একটি আদর্শ, সুশিক্ষিত ও স্বাবলম্বী সমাজ হিসেবে গড়ে তুলতে আমরা অঙ্গীকারবদ্ধ।'
  },
  {
    id: 'c2',
    name: 'আলহাজ্ব মোঃ নুরুল ইসলাম',
    designation: 'সহ-সভাপতি',
    phone: '+8801812345678',
    photoUrl: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=300&auto=format&fit=crop&q=80',
    priority: 2
  },
  {
    id: 'c3',
    name: 'প্রকৌশলী মোঃ শাহাদাত হোসেন',
    designation: 'সাধারণ সম্পাদক',
    phone: '+8801911987654',
    photoUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&auto=format&fit=crop&q=80',
    priority: 3,
    speech: 'ডিজিটাল প্রযুক্তির ছোঁয়ায় আমাদের পরিষদকে আরও সুসংগঠিত ও স্বচ্ছ করতে এই অ্যাপ চালু করা হলো। সকলে ঐক্যবদ্ধ থাকুন।'
  },
  {
    id: 'c4',
    name: 'মাওলানা মোঃ মাহমুদুল হাসান',
    designation: 'যুগ্ম সাধারণ সম্পাদক',
    phone: '+8801611554433',
    photoUrl: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=300&auto=format&fit=crop&q=80',
    priority: 4
  },
  {
    id: 'c5',
    name: 'মোঃ জহিরুল ইসলাম',
    designation: 'সাংগঠনিক সম্পাদক',
    phone: '+8801712334455',
    photoUrl: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=300&auto=format&fit=crop&q=80',
    priority: 5
  },
  {
    id: 'c6',
    name: 'কাজী মোঃ তৌহিদুল আলম',
    designation: 'অর্থ ও কোষাধ্যক্ষ',
    phone: '+8801819887766',
    photoUrl: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=300&auto=format&fit=crop&q=80',
    priority: 6
  },
  {
    id: 'c7',
    name: 'ড. মোঃ রফিকুল ইসলাম',
    designation: 'প্রচার ও প্রকাশনা সম্পাদক',
    phone: '+8801915443322',
    photoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80',
    priority: 7
  },
  {
    id: 'c8',
    name: 'মোঃ তানভীর আহমেদ',
    designation: 'সমাজসেবা ও মানবিক সম্পাদক',
    phone: '+8801612998877',
    photoUrl: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=300&auto=format&fit=crop&q=80',
    priority: 8
  }
];

export const INITIAL_NOTICES: Notice[] = [
  {
    id: 'n1',
    title: 'বার্ষিক সাধারণ সভা ২০২৬ ও ঈদ পুনর্মিলনী',
    date: '২০২৬-০৮-১০',
    category: 'সভা',
    content: 'আগামী ১০ আগস্ট ২০২৬, রবিবার বিকাল ৪:০০ টায় ছাদেক মোহাম্মদ পাড়া জামে মসজিদ মাঠে ঐক্য পরিষদের বার্ষিক সাধারণ সভা ও ঈদ পুনর্মিলনী অনুষ্ঠিত হবে। সকল সম্মানীত সদস্যকে সময়মত উপস্থিত থাকার জন্য বিনীত অনুরোধ জানানো হচ্ছে।',
    isUrgent: true,
    publishedBy: 'সাধারণ সম্পাদক'
  },
  {
    id: 'n2',
    title: 'জরুরি রক্তদান ক্যাম্পেইন ও ফ্রি ব্লাড গ্রুপিং',
    date: '২০২৬-০৭-২৮',
    category: 'জরুরি',
    content: 'ঐক্য পরিষদের উদ্যোগে বিনামূল্যে রক্তের গ্রুপ পরীক্ষা ও সেচ্ছায় রক্তদান ক্যাম্পেইন অনুষ্ঠিত হবে। স্থান: স্থানীয় প্রাথমিক বিদ্যালয় প্রাঙ্গণ। সময়: সকাল ৯:০০ টা হতে দুপুর ২:০০ টা।',
    isUrgent: true,
    publishedBy: 'মানবিক বিষয়ক সম্পাদক'
  },
  {
    id: 'n3',
    title: 'ডিজিটাল সদস্য আইডি কার্ড বিতরণ প্রসঙ্গে',
    date: '২০২৬-০৭-২০',
    category: 'সাধারণ',
    content: 'যে সকল সদস্য অনলাইনে নিবন্ধন সম্পন্ন করেছেন, তাদের ডিজিটাল কিউআর কোড যুক্ত সদস্য আইডি কার্ড অ্যাপ থেকে ডাউনলোড অথবা অফিস থেকে সংগ্রহ করার জন্য অনুরোধ করা যাচ্ছে।',
    publishedBy: 'দপ্তর সম্পাদক'
  },
  {
    id: 'n4',
    title: 'পরিচ্ছন্ন পাড়া ও ডেঙ্গু প্রতিরোধ সচেতনতা অভিযান',
    date: '২০২৬-০৭-১৫',
    category: 'ইভেন্ট',
    content: 'বর্ষা মৌসুমে ডেঙ্গু প্রতিরোধে আমাদের পাড়ার প্রতিটি রাস্তা ও ড্রেন পরিষ্কার করার কর্মসূচি গ্রহণ করা হয়েছে। স্বেচ্ছাসেবক হিসেবে যোগ দিতে যোগাযোগ করুন।',
    publishedBy: 'সমাজকল্যাণ সম্পাদক'
  }
];

export const INITIAL_ACTIVITIES: Activity[] = [
  {
    id: 'a1',
    title: 'বন্যা ও জরুরি দুর্যোগ ত্রাণ বিতরণ',
    category: 'ত্রাণ বিতরণ',
    description: 'আক্রান্ত পরিবার সমূহের মাঝে শুকনো খাবার, বিশুদ্ধ পানি ও শিশু খাদ্য বিতরণ কর্মসূচি।',
    date: '২০২৬-০৬-১২',
    imageUrl: 'https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?w=600&auto=format&fit=crop&q=80',
    targetAmount: 50000,
    raisedAmount: 46500,
    beneficiariesCount: 120,
    status: 'completed'
  },
  {
    id: 'a2',
    title: 'জরুরি ব্লাড ব্যাংক ও মুমূর্ষু রোগীকে রক্তদান',
    category: 'রক্তদান',
    description: 'আমাদের পাড়ার যুবকদের স্বেচ্ছায় রক্তদান নেটওয়ার্ক। বিগত ৩ মাসে ৪৫ ব্যাগ রক্ত সরবরাহ করা হয়েছে।',
    date: 'চলমান',
    imageUrl: 'https://images.unsplash.com/photo-1615461066841-6116e61058f4?w=600&auto=format&fit=crop&q=80',
    beneficiariesCount: 45,
    status: 'active'
  },
  {
    id: 'a3',
    title: 'মেধাবী ও দুস্থ শিক্ষার্থীদের শিক্ষাবৃত্তি ২০২৬',
    category: 'শিক্ষা',
    description: 'পাড়ার এসএসসি ও এইচএসসি পরীক্ষায় কৃতিত্ব অর্জনকারী দুস্থ শিক্ষার্থীদের বই ও আর্থিক সহায়তা প্রদান।',
    date: '২০২৬-০৮-২৫',
    imageUrl: 'https://images.unsplash.com/photo-1509062522246-3755977927d7?w=600&auto=format&fit=crop&q=80',
    targetAmount: 30000,
    raisedAmount: 20500,
    beneficiariesCount: 25,
    status: 'active'
  },
  {
    id: 'a4',
    title: 'গ্রীষ্মকালীন বৃক্ষরোপণ অভিযান ২০২৬',
    category: 'পরিচ্ছন্নতা',
    description: 'পাড়ার প্রধান সড়কের দুই পাশে ও মসজিদ প্রাঙ্গণে ১০০টি ফলজ ও ঔষধি গাছ রোপণ কর্মসূচি।',
    date: '২০২৬-০৫-৩০',
    imageUrl: 'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?w=600&auto=format&fit=crop&q=80',
    beneficiariesCount: 300,
    status: 'completed'
  }
];

export const INITIAL_EVENTS: EventItem[] = [
  {
    id: 'e1',
    title: 'স্বেচ্ছায় রক্তদান ও হেলথ ক্যাম্প',
    date: '২০২৬-০৭-২৮',
    time: 'সকাল ০৯:০০ - দুপুর ০২:০০',
    location: 'ছাদেক মোহাম্মদ পাড়া প্রাথমিক বিদ্যালয় মাঠ',
    description: 'অভিজ্ঞ ডাক্তার দ্বারা বিনামূল্যে চিকিৎসা সেবা ও রক্তের গ্রুপ পরীক্ষা।',
    category: 'স্বাস্থ্য',
    status: 'upcoming'
  },
  {
    id: 'e2',
    title: 'বার্ষিক সাধারণ সভা ও ভোজ',
    date: '২০২৬-০৮-১০',
    time: 'বিকাল ০৪:০০ - রাত ০৯:০০',
    location: 'কমিউনিটি সেন্টারে',
    description: 'সংগঠনের হিসাব পেশ, নতুন কার্যকরী কমিটি গঠন ও প্রীতিভোজ।',
    category: 'সভা',
    status: 'upcoming'
  },
  {
    id: 'e3',
    title: 'ঐক্য পরিষদ প্রীতি ফুটবল ম্যাচ',
    date: '২০২৬-০৮-২০',
    time: 'বিকাল ০৪:৩০',
    location: 'মাদরাসা মাঠ প্রাঙ্গণ',
    description: 'তরুণ বনাম প্রবীণ একাদশের ঐতিহ্যবাহী ফুটবল প্রতিযোগিতা।',
    category: 'খেলাধুলা',
    status: 'upcoming'
  }
];

export const INITIAL_MEMBERS: Member[] = [
  {
    id: 'm1',
    memberNo: 'SMP-2026-001',
    nameBn: 'মোঃ ছাদেক হোসেন',
    nameEn: 'Md. Sadek Hossain',
    phone: '01711122233',
    address: 'বাড়ি নং ৪২, উত্তর পাড়া, ছাদেক মোহাম্মদ পাড়া',
    nid: '1988269123456789',
    bloodGroup: 'O+',
    photoUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop&q=80',
    joinDate: '২০২৩-০১-১৫',
    status: 'approved',
    role: 'executive',
    fatherName: 'মরহুম হাজী মোহাম্মদ আলী',
    occupation: 'ব্যবসায়ী'
  },
  {
    id: 'm2',
    memberNo: 'SMP-2026-002',
    nameBn: 'মোঃ আরিফুর রহমান',
    nameEn: 'Md. Arifur Rahman',
    phone: '01822233344',
    address: 'মধ্য পাড়া, ছাদেক মোহাম্মদ পাড়া',
    nid: '1995269876543210',
    bloodGroup: 'A+',
    photoUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&auto=format&fit=crop&q=80',
    joinDate: '২০২৪-০৩-১০',
    status: 'approved',
    role: 'volunteer',
    fatherName: 'মোঃ রফিকুল ইসলাম',
    occupation: 'চাকরিজীবী'
  },
  {
    id: 'm3',
    memberNo: 'SMP-2026-003',
    nameBn: 'কাজী কামরুল হাসান',
    nameEn: 'Kazi Kamrul Hasan',
    phone: '01933344455',
    address: 'দক্ষিণ পাড়া, ছাদেক মোহাম্মদ পাড়া',
    nid: '1992269554433221',
    bloodGroup: 'B+',
    photoUrl: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=300&auto=format&fit=crop&q=80',
    joinDate: '২০২৪-০৫-২০',
    status: 'approved',
    role: 'member',
    fatherName: 'কাজী আব্দুল জলিল',
    occupation: 'শিক্ষক'
  }
];

export const INITIAL_DONATIONS: Donation[] = [
  {
    id: 'd1',
    receiptNo: 'REC-2026-8821',
    donorName: 'মোঃ আব্দুল মান্নান',
    phone: '01712000111',
    amount: 5000,
    method: 'bKash',
    transactionId: 'BK8X92M1L2',
    cause: 'ত্রাণ তহবিল',
    date: '২০২৬-০৭-১৮',
    status: 'verified'
  },
  {
    id: 'd2',
    receiptNo: 'REC-2026-8822',
    donorName: 'ইঞ্জিনিয়ার জহির রায়হান',
    phone: '01819000222',
    amount: 10000,
    method: 'Nagad',
    transactionId: 'NG7721KK09',
    cause: 'শিক্ষাবৃত্তি ফান্ড',
    date: '২০২৬-০৭-১৯',
    status: 'verified'
  },
  {
    id: 'd3',
    receiptNo: 'REC-2026-8823',
    donorName: 'নাম প্রকাশে অনিচ্ছুক',
    phone: '01911000333',
    amount: 2000,
    method: 'Rocket',
    transactionId: 'RK99281726',
    cause: 'সাধারণ কল্যাণ ফান্ড',
    date: '২০২৬-০৭-২১',
    status: 'verified'
  }
];

export const INITIAL_GALLERY: GalleryItem[] = [
  {
    id: 'g1',
    title: 'শীতবস্ত্র বিতরণ কর্মসূচি ২০২৫',
    category: 'মানবতা',
    imageUrl: 'https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?w=600&auto=format&fit=crop&q=80',
    date: '২০২৫-১২-২০',
    type: 'image'
  },
  {
    id: 'g2',
    title: 'বার্ষিক ক্রীড়া প্রতিযোগিতা ও পুরষ্কার বিতরণী',
    category: 'ইভেন্ট',
    imageUrl: 'https://images.unsplash.com/photo-1511632765486-a01980e01a18?w=600&auto=format&fit=crop&q=80',
    date: '২০২৬-০২-১৫',
    type: 'image'
  },
  {
    id: 'g3',
    title: 'সেচ্ছায় রক্তদান শিবিরের উদ্বোধনী অনুষ্ঠান',
    category: 'স্বাস্থ্য',
    imageUrl: 'https://images.unsplash.com/photo-1615461066841-6116e61058f4?w=600&auto=format&fit=crop&q=80',
    date: '২০২৬-০৪-১০',
    type: 'image'
  },
  {
    id: 'g4',
    title: 'ঐক্য পরিষদ কেন্দ্রীয় অফিস শুভ উদ্বোধন',
    category: 'উদ্বোধন',
    imageUrl: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=600&auto=format&fit=crop&q=80',
    date: '২০২৪-১১-০১',
    type: 'image'
  }
];
