export type Language = 'bn' | 'en';

export interface Member {
  id: string;
  memberNo: string;
  nameBn: string;
  nameEn: string;
  phone: string;
  address: string;
  nid?: string;
  bloodGroup: string;
  photoUrl: string;
  joinDate: string;
  status: 'pending' | 'approved' | 'rejected';
  role: 'member' | 'volunteer' | 'executive';
  fatherName?: string;
  occupation?: string;
}

export interface CommitteeMember {
  id: string;
  name: string;
  designation: string;
  phone: string;
  email?: string;
  photoUrl: string;
  priority: number;
  speech?: string;
  address?: string;
}

export interface Notice {
  id: string;
  title: string;
  date: string;
  category: 'জরুরি' | 'সভা' | 'ইভেন্ট' | 'সাধারণ';
  content: string;
  isUrgent?: boolean;
  publishedBy: string;
  pdfUrl?: string;
}

export interface Activity {
  id: string;
  title: string;
  category: 'রক্তদান' | 'ত্রাণ বিতরণ' | 'অসহায় সহায়তা' | 'পরিচ্ছন্নতা' | 'শিক্ষা';
  description: string;
  date: string;
  imageUrl: string;
  targetAmount?: number;
  raisedAmount?: number;
  beneficiariesCount?: number;
  status: 'active' | 'completed' | 'upcoming';
}

export interface EventItem {
  id: string;
  title: string;
  date: string;
  time: string;
  location: string;
  description: string;
  category: string;
  status: 'upcoming' | 'ongoing' | 'completed';
}

export interface Donation {
  id: string;
  receiptNo: string;
  donorName: string;
  phone: string;
  amount: number;
  method: 'bKash' | 'Nagad' | 'Rocket' | 'Bank';
  transactionId: string;
  cause: string;
  date: string;
  status: 'verified' | 'pending';
}

export interface GalleryItem {
  id: string;
  title: string;
  category: string;
  imageUrl: string;
  date: string;
  type: 'image' | 'video';
}

export interface Opinion {
  id: string;
  name: string;
  phone: string;
  message: string;
  date: string;
  rating?: number;
}
