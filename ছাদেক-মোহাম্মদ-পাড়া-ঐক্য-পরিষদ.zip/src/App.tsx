import React, { useState, useEffect } from 'react';
import { SplashScreen } from './components/SplashScreen';
import { Header } from './components/Header';
import { Navigation, TabType } from './components/Navigation';
import { HomeScreen } from './components/HomeScreen';
import { AboutSection } from './components/AboutSection';
import { CommitteeSection } from './components/CommitteeSection';
import { MemberRegistration } from './components/MemberRegistration';
import { DigitalIdCard } from './components/DigitalIdCard';
import { DonationSection } from './components/DonationSection';
import { NoticeSection } from './components/NoticeSection';
import { HumanitarianSection } from './components/HumanitarianSection';
import { EventCalendar } from './components/EventCalendar';
import { GallerySection } from './components/GallerySection';
import { FeedbackAndContact } from './components/FeedbackAndContact';
import { AdminPanel } from './components/AdminPanel';

import { Language, Member, Notice, Activity, EventItem, Donation, Opinion, GalleryItem } from './types';
import { 
  INITIAL_COMMITTEE, 
  INITIAL_NOTICES, 
  INITIAL_ACTIVITIES, 
  INITIAL_EVENTS, 
  INITIAL_MEMBERS, 
  INITIAL_DONATIONS, 
  INITIAL_GALLERY 
} from './data/initialData';

export default function App() {
  const [showSplash, setShowSplash] = useState(true);
  const [activeTab, setActiveTab] = useState<TabType>('home');
  const [language, setLanguage] = useState<Language>('bn');
  const [darkMode, setDarkMode] = useState(false);
  const [isMobileFrame, setIsMobileFrame] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // State Collections
  const [members, setMembers] = useState<Member[]>(INITIAL_MEMBERS);
  const [notices, setNotices] = useState<Notice[]>(INITIAL_NOTICES);
  const [activities, setActivities] = useState<Activity[]>(INITIAL_ACTIVITIES);
  const [events, setEvents] = useState<EventItem[]>(INITIAL_EVENTS);
  const [donations, setDonations] = useState<Donation[]>(INITIAL_DONATIONS);
  const [gallery, setGallery] = useState<GalleryItem[]>(INITIAL_GALLERY);
  const [opinions, setOpinions] = useState<Opinion[]>([]);

  // Notice Detail Modal state
  const [selectedNoticeDetail, setSelectedNoticeDetail] = useState<Notice | null>(null);

  // Notification Toast state
  const [showNotificationToast, setShowNotificationToast] = useState(false);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const handleAddMember = (newMem: Member) => {
    setMembers([newMem, ...members]);
  };

  const handleApproveMember = (id: string) => {
    setMembers(members.map(m => m.id === id ? { ...m, status: 'approved' } : m));
  };

  const handleAddNotice = (newNotice: Notice) => {
    setNotices([newNotice, ...notices]);
  };

  const handleAddEvent = (newEvent: EventItem) => {
    setEvents([newEvent, ...events]);
  };

  const handleAddDonation = (newDonation: Donation) => {
    setDonations([newDonation, ...donations]);
  };

  const handleAddOpinion = (newOpinion: Opinion) => {
    setOpinions([newOpinion, ...opinions]);
  };

  const urgentNoticesCount = notices.filter(n => n.isUrgent).length;

  return (
    <div className={`min-h-screen transition-colors duration-300 ${darkMode ? 'dark bg-slate-950 text-slate-100' : 'bg-[#f0f4f1] text-[#2d3748]'}`}>
      {/* Animated Splash Intro Screen */}
      {showSplash && <SplashScreen onFinish={() => setShowSplash(false)} />}

      {/* Main Container Wrapper - Supports standard Web View and Mobile Frame View */}
      <div className={isMobileFrame ? 'max-w-[430px] mx-auto min-h-screen shadow-2xl border-x border-slate-300 dark:border-slate-800 bg-white dark:bg-slate-900 relative my-0 sm:my-4 sm:rounded-[40px] overflow-hidden' : 'w-full'}>
        
        {/* App Header */}
        <Header
          language={language}
          onToggleLanguage={() => setLanguage(language === 'bn' ? 'en' : 'bn')}
          darkMode={darkMode}
          onToggleDarkMode={() => setDarkMode(!darkMode)}
          isMobileFrame={isMobileFrame}
          onToggleMobileFrame={() => setIsMobileFrame(!isMobileFrame)}
          isAdmin={isAdmin}
          onToggleAdmin={() => {
            setIsAdmin(!isAdmin);
            if (!isAdmin) setActiveTab('admin');
            else if (activeTab === 'admin') setActiveTab('home');
          }}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          onOpenNotifications={() => {
            setActiveTab('notice');
            setShowNotificationToast(true);
            setTimeout(() => setShowNotificationToast(false), 3000);
          }}
          activeMemberCount={members.length}
          unreadNoticesCount={urgentNoticesCount}
        />

        {/* Navigation Bar */}
        <Navigation
          activeTab={activeTab}
          onSelectTab={setActiveTab}
          unreadNoticesCount={urgentNoticesCount}
          isAdmin={isAdmin}
        />

        {/* Main Body View */}
        <main className="max-w-7xl mx-auto px-4 py-6 mb-16 md:mb-6">
          {/* Global Search Results Filter Banner if query exists */}
          {searchQuery && (
            <div className="mb-6 p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-800 text-xs text-amber-900 dark:text-amber-200">
              <span className="font-bold">খোঁজা হচ্ছে: "{searchQuery}"</span>
              <p className="text-[11px] mt-0.5">নিচের মেনুগুলোতে প্রাসঙ্গিক তথ্য অনুসন্ধান করা হচ্ছে।</p>
            </div>
          )}

          {activeTab === 'home' && (
            <HomeScreen
              onNavigate={setActiveTab}
              committee={INITIAL_COMMITTEE}
              notices={notices}
              activities={activities}
              events={events}
              members={members}
              onOpenNoticeDetail={(notice) => {
                setSelectedNoticeDetail(notice);
                setActiveTab('notice');
              }}
              onOpenActivityDetail={() => setActiveTab('humanitarian')}
            />
          )}

          {activeTab === 'about' && <AboutSection />}

          {activeTab === 'committee' && <CommitteeSection committee={INITIAL_COMMITTEE} />}

          {activeTab === 'register' && (
            <MemberRegistration
              onRegisterMember={handleAddMember}
              existingMembers={members}
            />
          )}

          {activeTab === 'idcard' && (
            <div className="space-y-6">
              <div className="text-center space-y-2 max-w-xl mx-auto">
                <h2 className="text-2xl font-extrabold text-slate-900 dark:text-white font-['Noto_Serif_Bengali']">
                  ডিজিটাল সদস্য আইডি কার্ড
                </h2>
                <p className="text-xs text-slate-600 dark:text-slate-300">
                  আপনার কিউআর কোড যুক্ত অফিশিয়াল আইডি কার্ড দেখুন ও ডাউনলোড করুন
                </p>
              </div>
              <DigitalIdCard member={members[0]} />
            </div>
          )}

          {activeTab === 'donation' && (
            <DonationSection
              donations={donations}
              onAddDonation={handleAddDonation}
            />
          )}

          {activeTab === 'notice' && (
            <NoticeSection
              notices={notices}
              selectedNoticeDetail={selectedNoticeDetail}
              onSelectNoticeDetail={setSelectedNoticeDetail}
            />
          )}

          {activeTab === 'humanitarian' && (
            <HumanitarianSection activities={activities} />
          )}

          {activeTab === 'events' && <EventCalendar events={events} />}

          {activeTab === 'gallery' && <GallerySection gallery={gallery} />}

          {activeTab === 'feedback' && (
            <FeedbackAndContact
              opinions={opinions}
              onAddOpinion={handleAddOpinion}
            />
          )}

          {activeTab === 'contact' && (
            <FeedbackAndContact
              opinions={opinions}
              onAddOpinion={handleAddOpinion}
            />
          )}

          {activeTab === 'admin' && isAdmin && (
            <AdminPanel
              members={members}
              onApproveMember={handleApproveMember}
              notices={notices}
              onAddNotice={handleAddNotice}
              events={events}
              onAddEvent={handleAddEvent}
              donations={donations}
            />
          )}
        </main>

        {/* Global Footer */}
        <footer className="bg-emerald-950 text-white pt-8 pb-16 md:pb-8 border-t border-emerald-900 text-xs">
          <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-3 gap-6 text-emerald-200">
            <div className="space-y-2">
              <h3 className="text-sm font-bold text-white font-['Noto_Serif_Bengali']">
                ছাদেক মোহাম্মদ পাড়া ঐক্য পরিষদ
              </h3>
              <p className="text-[11px] leading-relaxed text-emerald-300">
                ঐক্যে শক্তি, মানবতায় সেবা — আমাদের এলাকার প্রতিটি মানুষের কল্যাণ ও সামাজিক উন্নয়নে নিবেদিত অফিশিয়াল প্ল্যাটফর্ম।
              </p>
            </div>

            <div className="space-y-1">
              <h4 className="font-bold text-amber-300 text-xs">দ্রুত লিঙ্কসমূহ</h4>
              <div className="grid grid-cols-2 gap-1 text-[11px]">
                <button onClick={() => setActiveTab('about')} className="text-left hover:underline">আমাদের সম্পর্কে</button>
                <button onClick={() => setActiveTab('committee')} className="text-left hover:underline">কমিটি সদস্য</button>
                <button onClick={() => setActiveTab('register')} className="text-left hover:underline">সদস্য নিবন্ধন</button>
                <button onClick={() => setActiveTab('donation')} className="text-left hover:underline">অনুদানের ফান্ড</button>
                <button onClick={() => setActiveTab('notice')} className="text-left hover:underline">নোটিশ বোর্ড</button>
                <button onClick={() => setActiveTab('humanitarian')} className="text-left hover:underline">রক্তদান সেবা</button>
              </div>
            </div>

            <div className="space-y-1">
              <h4 className="font-bold text-sky-300 text-xs">যোগাযোগ ও হেল্পলাইন</h4>
              <p className="text-[11px]">📍 ছাদেক মোহাম্মদ পাড়া, ওয়ার্ড নং ৪</p>
              <p className="text-[11px]">📞 +880 1711-223344</p>
              <p className="text-[11px]">📧 sadekpara@gmail.com</p>
            </div>
          </div>

          <div className="max-w-7xl mx-auto px-4 mt-6 pt-4 border-t border-emerald-900/60 text-center text-[10px] text-emerald-400">
            © ২০২৬ ছাদেক মোহাম্মদ পাড়া ঐক্য পরিষদ। সর্বস্বত্ব সংরক্ষিত।
          </div>
        </footer>
      </div>
    </div>
  );
}
